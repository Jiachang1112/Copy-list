import UIKit

/// 顯示「剪貼清單」歷史的鍵盤：點一下項目就輸入到目前的輸入框
///
/// 資料來源（有哪個用哪個，最後合併）：
/// 1. App Group 共用檔（簽名工具有保留 App Group 時）
/// 2. 具名剪貼簿備援（App 端同步出來）
/// 3. 鍵盤自己記錄：每次鍵盤出現時，把目前剪貼簿的文字存在鍵盤自己的資料夾（需要「允許完整取用」）
final class KeyboardViewController: UIInputViewController {
    private let tableView = UITableView(frame: .zero, style: .plain)
    private let emptyLabel = UILabel()
    private let statusLabel = UILabel()
    private var items: [ClipItem] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        buildUI()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        reload()
    }

    // MARK: - 畫面

    private func buildUI() {
        let height = view.heightAnchor.constraint(equalToConstant: 290)
        height.priority = UILayoutPriority(999)
        height.isActive = true

        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.backgroundColor = .clear
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")

        emptyLabel.translatesAutoresizingMaskIntoConstraints = false
        emptyLabel.text = "還沒有內容。\n先在任何 App 複製文字，再切到這個鍵盤就會記錄。\n（需要開啟「允許完整取用」）"
        emptyLabel.numberOfLines = 0
        emptyLabel.textAlignment = .center
        emptyLabel.textColor = .secondaryLabel
        emptyLabel.font = .systemFont(ofSize: 14)

        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        statusLabel.textAlignment = .center
        statusLabel.textColor = .tertiaryLabel
        statusLabel.font = .systemFont(ofSize: 10)
        statusLabel.numberOfLines = 1
        statusLabel.adjustsFontSizeToFitWidth = true
        statusLabel.minimumScaleFactor = 0.7

        let globeButton = makeButton(systemImage: "globe")
        globeButton.addTarget(self, action: #selector(handleInputModeList(from:with:)), for: .allTouchEvents)

        let spaceButton = makeButton(title: "空白")
        spaceButton.addTarget(self, action: #selector(tapSpace), for: .touchUpInside)

        let deleteButton = makeButton(systemImage: "delete.left")
        deleteButton.addTarget(self, action: #selector(tapDelete), for: .touchUpInside)

        let returnButton = makeButton(systemImage: "return")
        returnButton.addTarget(self, action: #selector(tapReturn), for: .touchUpInside)

        let bar = UIStackView(arrangedSubviews: [globeButton, spaceButton, deleteButton, returnButton])
        bar.translatesAutoresizingMaskIntoConstraints = false
        bar.axis = .horizontal
        bar.spacing = 8
        bar.distribution = .fill

        view.addSubview(tableView)
        view.addSubview(emptyLabel)
        view.addSubview(statusLabel)
        view.addSubview(bar)

        NSLayoutConstraint.activate([
            bar.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 8),
            bar.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -8),
            bar.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -6),
            bar.heightAnchor.constraint(equalToConstant: 42),

            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 8),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -8),
            statusLabel.bottomAnchor.constraint(equalTo: bar.topAnchor, constant: -2),
            statusLabel.heightAnchor.constraint(equalToConstant: 14),

            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: statusLabel.topAnchor, constant: -2),

            emptyLabel.centerYAnchor.constraint(equalTo: tableView.centerYAnchor),
            emptyLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            emptyLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24),

            globeButton.widthAnchor.constraint(equalToConstant: 56),
            deleteButton.widthAnchor.constraint(equalToConstant: 56),
            returnButton.widthAnchor.constraint(equalToConstant: 56)
        ])
    }

    private func makeButton(title: String? = nil, systemImage: String? = nil) -> UIButton {
        let button = UIButton(type: .system)
        if let title = title {
            button.setTitle(title, for: .normal)
        }
        if let name = systemImage {
            button.setImage(UIImage(systemName: name), for: .normal)
        }
        button.tintColor = .label
        button.backgroundColor = .systemGray4
        button.layer.cornerRadius = 8
        return button
    }

    // MARK: - 資料

    private func reload() {
        captureGeneralPasteboard()

        let fileItems = ClipFile.loadFile()
        let pasteboardItems = ClipShare.loadFromPasteboard()
        let own = loadOwn()

        var merged = fileItems.isEmpty ? pasteboardItems : fileItems
        for item in own where !merged.contains(where: { $0.text == item.text }) {
            merged.append(item)
        }

        // 釘選的排前面，其餘照時間（最新在前）
        items = merged.sorted { a, b in
            if a.pinned != b.pinned { return a.pinned }
            return a.date > b.date
        }

        emptyLabel.isHidden = !items.isEmpty
        tableView.reloadData()

        let access = hasFullAccess ? "開" : "關"
        let group = ClipFile.groupAvailable ? "有" : "無"
        statusLabel.text = "診斷：完整取用\(access)｜App Group\(group)｜共用檔\(fileItems.count)｜備援\(pasteboardItems.count)｜本機\(own.count)"
    }

    // MARK: - 鍵盤自己記錄剪貼簿

    private var ownFileURL: URL {
        let fm = FileManager.default
        let dir = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent("keyboard_clips.json")
    }

    private func loadOwn() -> [ClipItem] {
        guard let data = try? Data(contentsOf: ownFileURL),
              let decoded = try? JSONDecoder().decode([ClipItem].self, from: data) else { return [] }
        return decoded
    }

    private func saveOwn(_ list: [ClipItem]) {
        guard let data = try? JSONEncoder().encode(list) else { return }
        try? data.write(to: ownFileURL, options: .atomic)
    }

    private func captureGeneralPasteboard() {
        guard hasFullAccess else { return }
        let pb = UIPasteboard.general
        guard pb.hasStrings, let text = pb.string,
              !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }

        var own = loadOwn()
        if let index = own.firstIndex(where: { $0.text == text }) {
            var item = own.remove(at: index)
            item.date = Date()
            own.insert(item, at: 0)
        } else {
            own.insert(ClipItem(text: text), at: 0)
        }
        saveOwn(Array(own.prefix(100)))
    }

    // MARK: - 按鈕

    @objc private func tapSpace() {
        textDocumentProxy.insertText(" ")
    }

    @objc private func tapDelete() {
        textDocumentProxy.deleteBackward()
    }

    @objc private func tapReturn() {
        textDocumentProxy.insertText("\n")
    }
}

// MARK: - 清單

extension KeyboardViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        items.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let item = items[indexPath.row]
        var content = cell.defaultContentConfiguration()
        content.text = (item.pinned ? "📌 " : "") + item.text
        content.textProperties.numberOfLines = 2
        cell.contentConfiguration = content
        cell.backgroundColor = .clear
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        textDocumentProxy.insertText(items[indexPath.row].text)
    }
}

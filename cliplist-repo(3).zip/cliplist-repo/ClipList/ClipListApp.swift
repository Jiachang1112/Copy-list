import SwiftUI

@main
struct ClipListApp: App {
    init() {
        ClipboardMonitor.shared.start()
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

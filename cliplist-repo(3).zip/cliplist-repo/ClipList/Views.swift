import SwiftUI
import UIKit

// MARK: - 主畫面

struct ContentView: View {
    @ObservedObject private var pip = PiPManager.shared
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        ZStack(alignment: .bottom) {
            TabView {
                HistoryView(pinnedOnly: false)
                    .tabItem { Label("剪貼簿", systemImage: "doc.on.clipboard") }
                HistoryView(pinnedOnly: true)
                    .tabItem { Label("常用", systemImage: "pin") }
                SettingsView()
                    .tabItem { Label("設定", systemImage: "gearshape") }
            }

            Button {
                if pip.isActive { pip.stop() } else { pip.start() }
            } label: {
                Label(pip.isActive ? "關閉背景剪貼簿" : "開啟背景剪貼簿",
                      systemImage: pip.isActive ? "stop.fill" : "play.fill")
                    .font(.headline)
                    .foregroundStyle(.white)
                    .padding(.horizontal, 22)
                    .padding(.vertical, 14)
                    .background(Capsule().fill(pip.isActive ? Color.red : Color.green))
            }
            .shadow(color: .black.opacity(0.2), radius: 6, y: 2)
            .padding(.bottom, 64)

            // 懸浮視窗的影像層需要掛在畫面上（幾乎透明，不會看到）
            PiPHostView()
                .frame(width: 32, height: 18)
                .opacity(0.02)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                .allowsHitTesting(false)
        }
        .onChange(of: scenePhase) { phase in
            if phase == .active { ClipboardMonitor.shared.check() }
        }
        .alert("提示", isPresented: Binding(
            get: { pip.message != nil },
            set: { if !$0 { pip.message = nil } }
        )) {
            Button("好", role: .cancel) {}
        } message: {
            Text(pip.message ?? "")
        }
    }
}

// MARK: - 歷史清單

struct HistoryView: View {
    @ObservedObject private var store = ClipStore.shared
    let pinnedOnly: Bool

    @State private var query = ""
    @State private var showToast = false

    private var filtered: [ClipItem] {
        store.items.filter { item in
            (!pinnedOnly || item.pinned) &&
            (query.isEmpty || item.text.localizedCaseInsensitiveContains(query))
        }
    }

    private var groups: [(day: Date, items: [ClipItem])] {
        let cal = Calendar.current
        let dict = Dictionary(grouping: filtered) { cal.startOfDay(for: $0.date) }
        return dict.keys.sorted(by: >).map { day in
            (day: day, items: (dict[day] ?? []).sorted { $0.date > $1.date })
        }
    }

    var body: some View {
        NavigationStack {
            List {
                ForEach(groups, id: \.day) { group in
                    Section {
                        ForEach(group.items) { item in
                            Button { copy(item) } label: { row(item) }
                                .buttonStyle(.plain)
                                .swipeActions(edge: .trailing) {
                                    Button(role: .destructive) {
                                        store.delete(item)
                                    } label: {
                                        Label("刪除", systemImage: "trash")
                                    }
                                }
                                .swipeActions(edge: .leading) {
                                    Button {
                                        store.togglePin(item)
                                    } label: {
                                        Label(item.pinned ? "取消釘選" : "釘選", systemImage: "pin")
                                    }
                                    .tint(.orange)
                                }
                                .contextMenu {
                                    Button { copy(item) } label: { Label("複製", systemImage: "doc.on.doc") }
                                    Button { store.togglePin(item) } label: {
                                        Label(item.pinned ? "取消釘選" : "釘選", systemImage: "pin")
                                    }
                                    Button(role: .destructive) { store.delete(item) } label: {
                                        Label("刪除", systemImage: "trash")
                                    }
                                }
                        }
                    } header: {
                        Text(group.day, format: .dateTime.year().month().day())
                    }
                }
            }
            .listStyle(.insetGrouped)
            .searchable(text: $query, prompt: "搜尋")
            .navigationTitle(pinnedOnly ? "常用" : "剪貼簿")
            .overlay {
                if groups.isEmpty {
                    Text(pinnedOnly ? "左滑項目即可釘選" : "還沒有內容，去複製些東西吧")
                        .foregroundStyle(.secondary)
                }
            }
            .overlay(alignment: .top) {
                if showToast {
                    Text("已複製")
                        .font(.subheadline.bold())
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background(.ultraThinMaterial, in: Capsule())
                        .padding(.top, 8)
                        .transition(.opacity)
                }
            }
        }
    }

    private func row(_ item: ClipItem) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 4) {
                Text(item.date, style: .time)
                if item.pinned { Image(systemName: "pin.fill") }
            }
            .font(.caption)
            .foregroundStyle(.secondary)

            Text(item.text)
                .font(.body)
                .lineLimit(3)
                .multilineTextAlignment(.leading)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .contentShape(Rectangle())
    }

    private func copy(_ item: ClipItem) {
        ClipboardMonitor.shared.copy(item.text)
        UINotificationFeedbackGenerator().notificationOccurred(.success)
        withAnimation { showToast = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            withAnimation { showToast = false }
        }
    }
}

// MARK: - 設定

struct SettingsView: View {
    @ObservedObject private var store = ClipStore.shared
    @ObservedObject private var pip = PiPManager.shared

    private var groupText: String {
        ClipFile.groupAvailable ? "可用" : "不可用（簽名工具沒保留）"
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Toggle("背景剪貼簿（懸浮視窗）", isOn: Binding(
                        get: { pip.isActive },
                        set: { $0 ? pip.start() : pip.stop() }
                    ))
                } header: {
                    Text("背景擷取")
                } footer: {
                    Text("開啟後會出現一個小視窗，切到其他 App 也會繼續記錄你複製的內容。")
                }

                Section {
                    Button {
                        if let url = URL(string: UIApplication.openSettingsURLString) {
                            UIApplication.shared.open(url)
                        }
                    } label: {
                        Label("開啟 iOS 設定", systemImage: "hand.raised")
                    }
                } header: {
                    Text("貼上權限")
                } footer: {
                    Text("到「剪貼清單 > 從其他 App 貼上」選「允許」，否則每次複製都會跳出貼上提示。")
                }

                Section {
                    Text("App Group：" + groupText)
                    Text("已記錄：\(store.items.count) 筆")
                } header: {
                    Text("鍵盤共用狀態")
                } footer: {
                    Text("App Group 不可用時，鍵盤會改走備援，並在你切到鍵盤時自己記錄剪貼簿。")
                }

                Section {
                    Stepper("最多保留 \(store.maxItems) 筆", value: $store.maxItems, in: 20...1000, step: 20)
                    Button("清除全部（保留釘選）", role: .destructive) {
                        store.clearUnpinned()
                    }
                } header: {
                    Text("儲存")
                }
            }
            .navigationTitle("設定")
        }
    }
}

// MARK: - 懸浮視窗影像層的容器

struct PiPHostView: UIViewRepresentable {
    func makeUIView(context: Context) -> PiPContainerView {
        PiPContainerView()
    }

    func updateUIView(_ uiView: PiPContainerView, context: Context) {}
}

final class PiPContainerView: UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        isUserInteractionEnabled = false
        layer.addSublayer(PiPManager.shared.displayLayer)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        PiPManager.shared.displayLayer.frame = bounds
    }
}

import Foundation
import UIKit

/// App 與鍵盤擴充共用的 App Group（兩邊要用同一個，才讀得到同一份資料）
let clipAppGroupID = "group.com.jiachang.cliplist"

struct ClipItem: Identifiable, Codable, Equatable {
    var id = UUID()
    var text: String
    var date = Date()
    var pinned = false
}

enum ClipFile {
    /// 資料檔位置：優先放在 App Group 共用資料夾；拿不到時退回 App 自己的資料夾
    static var url: URL {
        let fm = FileManager.default
        let legacyDir = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? fm.createDirectory(at: legacyDir, withIntermediateDirectories: true)
        let legacy = legacyDir.appendingPathComponent("clips.json")

        guard let group = fm.containerURL(forSecurityApplicationGroupIdentifier: clipAppGroupID) else {
            return legacy
        }
        let shared = group.appendingPathComponent("clips.json")
        // 第一次改用共用資料夾時，把舊資料搬過去
        if !fm.fileExists(atPath: shared.path), fm.fileExists(atPath: legacy.path) {
            try? fm.copyItem(at: legacy, to: shared)
        }
        return shared
    }

    /// App Group 是否可用（簽名工具有沒有保留）
    static var groupAvailable: Bool {
        FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: clipAppGroupID) != nil
    }

    /// 只讀資料檔（App Group 共用檔，或沒有 App Group 時是 App 自己的檔）
    static func loadFile() -> [ClipItem] {
        guard let data = try? Data(contentsOf: url),
              let decoded = try? JSONDecoder().decode([ClipItem].self, from: data) else { return [] }
        return decoded
    }
}

/// 備援通道：不靠 App Group，改用自訂名稱的剪貼簿在 App 與鍵盤之間傳資料。
/// 不影響一般剪貼簿的內容；鍵盤端需要「允許完整取用」才讀得到。
enum ClipShare {
    private static let pasteboardName = UIPasteboard.Name(rawValue: "com.jiachang.cliplist.shared")
    private static let pasteboardType = "com.jiachang.cliplist.json"

    /// App 端：把目前的清單同步出去
    static func publish(_ data: Data) {
        guard let pb = UIPasteboard(name: pasteboardName, create: true) else { return }
        pb.isPersistent = true
        pb.setData(data, forPasteboardType: pasteboardType)
    }

    /// 鍵盤端：讀取 App 同步出來的清單
    static func loadFromPasteboard() -> [ClipItem] {
        guard let pb = UIPasteboard(name: pasteboardName, create: false),
              let data = pb.data(forPasteboardType: pasteboardType),
              let decoded = try? JSONDecoder().decode([ClipItem].self, from: data) else { return [] }
        return decoded
    }
}

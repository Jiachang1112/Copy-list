# 剪貼清單 ClipList

類似「複製清單」的 iOS 剪貼簿工具：
- 懸浮視窗（子母畫面）在背景持續偵測複製的文字／網址
- 依日期分組的歷史清單、搜尋、釘選（常用）、左滑刪除
- 點一下項目就複製回剪貼簿

## 用 GitHub 產生 IPA
1. 把整個資料夾內容推到你的 GitHub repo（分支 main）
2. 到 Actions → Build IPA，等跑完（或手動 Run workflow）
3. 到 Releases 下載 `ClipList.ipa`（也可在 Actions 的 Artifacts 下載）
4. 此 IPA 沒簽名，用 Sideloadly / AltStore / TrollStore / ESign 等工具簽名安裝

## 使用
1. 開啟 App → 點「開啟背景剪貼簿」→ 出現小視窗
2. 回主畫面或切到別的 App，照常複製，內容會被記錄
3. iOS 設定 → 剪貼清單 → 從其他 App 貼上 → 允許

import Foundation
import Combine

final class ClipStore: ObservableObject {
    static let shared = ClipStore()

    @Published private(set) var items: [ClipItem] = []
    @Published var maxItems: Int {
        didSet {
            UserDefaults.standard.set(maxItems, forKey: "maxItems")
            trim()
            save()
        }
    }

    private var tombstones: [ClipTombstone] = []

    @Published private(set) var undoItems: [ClipItem] = []
    private var undoWork: DispatchWorkItem?

    private let fileURL: URL

    private init() {
        fileURL = ClipFile.url
        let saved = UserDefaults.standard.integer(forKey: "maxItems")
        maxItems = saved == 0 ? 200 : saved
        loadTombstones()
        load()
        trim()
        publishToKeyboard()
    }

    // MARK: 已刪除紀錄（讓鍵盤也跟著刪）

    private func loadTombstones() {
        guard let data = UserDefaults.standard.data(forKey: "tombstones"),
              let list = try? JSONDecoder().decode([ClipTombstone].self, from: data) else { return }
        tombstones = list
    }

    private func saveTombstones() {
        if let data = try? JSONEncoder().encode(tombstones) {
            UserDefaults.standard.set(data, forKey: "tombstones")
        }
    }

    private func addTombstones(_ texts: [String]) {
        guard !texts.isEmpty else { return }
        let now = Date()
        tombstones.removeAll { texts.contains($0.text) }
        tombstones.append(contentsOf: texts.map { ClipTombstone(text: $0, date: now) })
        // 只保留 30 天內、最多 300 筆
        let cutoff = Calendar.current.date(byAdding: .day, value: -30, to: now) ?? now
        tombstones = tombstones.filter { $0.date >= cutoff }
        if tombstones.count > 300 {
            tombstones.removeFirst(tombstones.count - 300)
        }
        saveTombstones()
    }

    private func removeTombstones(_ texts: [String]) {
        let before = tombstones.count
        tombstones.removeAll { texts.contains($0.text) }
        if tombstones.count != before {
            saveTombstones()
        }
    }

    // MARK: 設定值

    /// 0 = 不處理、1 = 不記錄、2 = 記錄但遮住並不同步（預設）
    private var sensitiveMode: Int {
        (UserDefaults.standard.object(forKey: "sensitiveMode") as? Int) ?? 2
    }

    private var keywordList: [String] {
        let raw = UserDefaults.standard.string(forKey: "ignoreKeywords") ?? ""
        return raw
            .split(whereSeparator: { ",，、\n".contains($0) })
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
    }

    func add(_ text: String) {
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }

        let mode = sensitiveMode
        let flagged = mode != 0 && ClipSensitive.looksSensitive(text, keywords: keywordList)
        if flagged && mode == 1 { return }
        removeTombstones([text])

        if let index = items.firstIndex(where: { $0.text == text }) {
            var item = items.remove(at: index)
            item.date = Date()
            if flagged && item.sensitive == nil { item.sensitive = true }
            items.insert(item, at: 0)
        } else {
            var item = ClipItem(text: text)
            if flagged { item.sensitive = true }
            items.insert(item, at: 0)
        }
        trim()
        save()
    }

    // MARK: 刪除與復原

    func delete(_ item: ClipItem) {
        delete(ids: [item.id])
    }

    func delete(ids: Set<UUID>) {
        let removed = items.filter { ids.contains($0.id) }
        guard !removed.isEmpty else { return }
        items.removeAll { ids.contains($0.id) }
        addTombstones(removed.map { $0.text })
        save()

        undoItems = removed
        undoWork?.cancel()
        let work = DispatchWorkItem { [weak self] in
            self?.undoItems = []
        }
        undoWork = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 6, execute: work)
    }

    func undoDelete() {
        guard !undoItems.isEmpty else { return }
        items.append(contentsOf: undoItems)
        items.sort { $0.date > $1.date }
        removeTombstones(undoItems.map { $0.text })
        undoItems = []
        undoWork?.cancel()
        save()
    }

    // MARK: 批次與標記

    func setPinned(ids: Set<UUID>, pinned: Bool) {
        for index in items.indices where ids.contains(items[index].id) {
            items[index].pinned = pinned
        }
        save()
    }

    func setCategory(ids: Set<UUID>, to name: String?) {
        let trimmed = (name ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        for index in items.indices where ids.contains(items[index].id) {
            items[index].category = trimmed.isEmpty ? nil : trimmed
        }
        save()
    }

    func toggleSensitive(_ item: ClipItem) {
        guard let index = items.firstIndex(where: { $0.id == item.id }) else { return }
        items[index].sensitive = !(items[index].sensitive == true)
        save()
    }

    func bumpUse(_ item: ClipItem) {
        guard let index = items.firstIndex(where: { $0.id == item.id }) else { return }
        items[index].useCount = (items[index].useCount ?? 0) + 1
        save()
    }

    // MARK: 備份

    func backupData() -> Data? {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        return try? encoder.encode(items)
    }

    /// 匯入備份：同 id 或同內容的略過，其餘加進來；回傳新增幾筆
    @discardableResult
    func importItems(_ list: [ClipItem]) -> Int {
        var added = 0
        for item in list {
            if items.contains(where: { $0.id == item.id || $0.text == item.text }) { continue }
            items.append(item)
            removeTombstones([item.text])
            added += 1
        }
        items.sort { $0.date > $1.date }
        trim()
        save()
        return added
    }

    func togglePin(_ item: ClipItem) {
        guard let index = items.firstIndex(where: { $0.id == item.id }) else { return }
        items[index].pinned.toggle()
        save()
    }

    /// 指定分類；name 為空（或 nil）代表恢復成自動分類
    func setCategory(_ item: ClipItem, to name: String?) {
        guard let index = items.firstIndex(where: { $0.id == item.id }) else { return }
        let trimmed = (name ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        items[index].category = trimmed.isEmpty ? nil : trimmed
        save()
    }

    /// 手動新增的片語：預設釘選，不會被自動清掉
    func addManual(_ text: String, category: String?) {
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        removeTombstones([text])
        items.removeAll { $0.text == text }
        var item = ClipItem(text: text)
        item.pinned = true
        let name = (category ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        item.category = name.isEmpty ? nil : name
        items.insert(item, at: 0)
        save()
    }

    /// 編輯內容；如果改完和別筆一樣，就合併成一筆
    func updateText(_ item: ClipItem, to newText: String) {
        guard !newText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              let index = items.firstIndex(where: { $0.id == item.id }) else { return }
        let oldText = items[index].text
        items[index].text = newText
        items.removeAll { $0.id != item.id && $0.text == newText }
        if oldText != newText {
            addTombstones([oldText])
            removeTombstones([newText])
        }
        save()
    }

    /// 重新命名自訂分類
    func renameCategory(_ old: String, to new: String) {
        let name = new.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty else { return }
        for index in items.indices where items[index].category == old {
            items[index].category = name
        }
        save()
    }

    /// 刪除自訂分類：裡面的項目回到自動分類
    func deleteCategory(_ name: String) {
        for index in items.indices where items[index].category == name {
            items[index].category = nil
        }
        save()
    }

    /// 處理從鍵盤送來的指令
    func apply(_ command: ClipCommand) {
        guard let index = items.firstIndex(where: { $0.id == command.id }) else { return }
        switch command.action {
        case "pin":
            items[index].pinned = true
        case "unpin":
            items[index].pinned = false
        case "delete":
            let text = items[index].text
            items.remove(at: index)
            addTombstones([text])
        case "use":
            items[index].useCount = (items[index].useCount ?? 0) + 1
        default:
            return
        }
        save()
    }

    /// 依「自動刪除」設定清掉舊項目
    func applyRetention() {
        trim()
        save()
    }

    func clearUnpinned() {
        delete(ids: Set(items.filter { !$0.pinned }.map { $0.id }))
    }

    private func trim() {
        let days = UserDefaults.standard.integer(forKey: "retentionDays")
        var cutoff: Date? = nil
        if days > 0 {
            cutoff = Calendar.current.date(byAdding: .day, value: -days, to: Date())
        }
        var count = 0
        let before = items
        items = items.filter { item in
            if item.pinned { return true }
            if let cutoff = cutoff, item.date < cutoff { return false }
            count += 1
            return count <= maxItems
        }
        if items.count != before.count {
            let kept = Set(items.map { $0.id })
            addTombstones(before.filter { !kept.contains($0.id) }.map { $0.text })
        }
    }

    private func load() {
        guard let data = try? Data(contentsOf: fileURL),
              let decoded = try? JSONDecoder().decode([ClipItem].self, from: data) else { return }
        items = decoded
    }

    private func save() {
        guard let data = try? JSONEncoder().encode(items) else { return }
        try? data.write(to: fileURL, options: .atomic)
        publishToKeyboard()
    }

    /// 設定頁改了同步筆數之後呼叫
    func republish() {
        publishToKeyboard()
    }

    /// 備援通道：App Group 可用就不用（內容不放在共用剪貼簿）；
    /// 否則只同步釘選＋最近 N 筆，而且不含敏感內容
    private func publishToKeyboard() {
        let tombstoneData = try? JSONEncoder().encode(tombstones)
        if ClipFile.groupAvailable {
            ClipShare.clear()
            if let tombstoneData = tombstoneData {
                ClipFile.writeDeleted(tombstoneData)
            }
            return
        }
        let limit = (UserDefaults.standard.object(forKey: "syncLimit") as? Int) ?? 30
        guard limit > 0 else {
            ClipShare.clear()
            return
        }
        let visible = items.filter { !$0.isSensitive }
        let pinned = visible.filter { $0.pinned }
        let recent = visible.filter { !$0.pinned }.prefix(limit)
        let payload = pinned + Array(recent)
        if let data = try? JSONEncoder().encode(payload) {
            ClipShare.publish(data)
        }
        if let tombstoneData = tombstoneData {
            ClipShare.publishDeleted(tombstoneData)
        }
    }
}

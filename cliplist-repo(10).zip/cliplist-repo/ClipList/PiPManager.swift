import AVKit
import Combine
import UIKit

/// 懸浮視窗：用「子母畫面 (PiP)」顯示最新複製的內容。
/// PiP 開著的時候 iOS 會讓 App 在背景繼續執行，所以才能持續偵測剪貼簿。
final class PiPManager: NSObject, ObservableObject {
    static let shared = PiPManager()

    @Published private(set) var isActive = false
    /// 使用者開啟過背景記錄；如果之後被系統中斷，畫面上會提醒重新開啟
    @Published private(set) var wantsRunning = false
    /// 正在啟動中（按下開啟之後、懸浮視窗真的出現之前）
    @Published private(set) var isStarting = false
    @Published var message: String?

    let displayLayer = AVSampleBufferDisplayLayer()

    private var pipController: AVPictureInPictureController?
    private var frameTimer: Timer?
    private var currentBuffer: CVPixelBuffer?
    private var latestText = "等待複製…"
    private var latestDate: Date?
    private var configured = false
    private var possibleObserver: AnyCancellable?
    private var startRequested = false
    private var startRetries = 0

    private override init() {
        super.init()
        displayLayer.videoGravity = .resizeAspect
        currentBuffer = render()
    }

    // MARK: - 開關

    func start() {
        guard AVPictureInPictureController.isPictureInPictureSupported() else {
            message = "這台裝置不支援懸浮視窗（子母畫面）"
            return
        }
        guard !isActive, !isStarting else { return }
        message = nil
        isStarting = true
        startRequested = false
        startRetries = 0
        prepare()
        activateAudioSession()
        tryStart(attempt: 0)
    }

    /// 事先把畫面和控制器準備好（App 一打開就呼叫），之後按「開啟」就能立刻啟動，不用再等
    func prepare() {
        guard AVPictureInPictureController.isPictureInPictureSupported() else { return }
        configureIfNeeded()
        if frameTimer == nil {
            startFrameTimer()
        }
    }

    func stop() {
        wantsRunning = false
        isStarting = false
        startRequested = false
        pipController?.stopPictureInPicture()
    }

    func show(text: String) {
        latestText = text
        latestDate = Date()
        currentBuffer = render()
        pushFrame()
    }

    // MARK: - 設定

    private func configureIfNeeded() {
        guard !configured else { return }
        configured = true

        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .moviePlayback, options: [.mixWithOthers])

        var timebase: CMTimebase?
        CMTimebaseCreateWithSourceClock(allocator: kCFAllocatorDefault,
                                        sourceClock: CMClockGetHostTimeClock(),
                                        timebaseOut: &timebase)
        if let timebase = timebase {
            CMTimebaseSetTime(timebase, time: CMClockGetTime(CMClockGetHostTimeClock()))
            CMTimebaseSetRate(timebase, rate: 1.0)
            displayLayer.controlTimebase = timebase
        }

        let source = AVPictureInPictureController.ContentSource(
            sampleBufferDisplayLayer: displayLayer,
            playbackDelegate: self
        )
        let controller = AVPictureInPictureController(contentSource: source)
        controller.delegate = self
        controller.canStartPictureInPictureAutomaticallyFromInline = true
        pipController = controller

        // 一旦系統說「可以啟動了」就立刻啟動，不用等輪詢
        possibleObserver = controller.publisher(for: \.isPictureInPicturePossible)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] possible in
                guard let self = self, possible, self.isStarting else { return }
                self.beginPiP()
            }
    }

    private func activateAudioSession() {
        try? AVAudioSession.sharedInstance().setActive(true)
    }

    private func beginPiP() {
        guard let controller = pipController,
              !startRequested,
              !controller.isPictureInPictureActive else { return }
        startRequested = true
        controller.startPictureInPicture()
    }

    private func tryStart(attempt: Int) {
        guard isStarting, let controller = pipController else { return }
        if controller.isPictureInPictureActive { return }
        if controller.isPictureInPicturePossible {
            beginPiP()
            return
        }
        if attempt < 50 {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
                self?.tryStart(attempt: attempt + 1)
            }
        } else {
            isStarting = false
            message = "無法啟動懸浮視窗，請確認沒有在其他 App 使用子母畫面"
        }
    }

    // MARK: - 影像幀

    private func startFrameTimer() {
        frameTimer?.invalidate()
        let t = Timer(timeInterval: 0.5, repeats: true) { [weak self] _ in
            self?.pushFrame()
        }
        RunLoop.main.add(t, forMode: .common)
        frameTimer = t
        pushFrame()
    }

    private func stopFrameTimer() {
        frameTimer?.invalidate()
        frameTimer = nil
    }

    private func pushFrame() {
        guard frameTimer != nil else { return }
        if displayLayer.status == .failed { displayLayer.flush() }
        guard displayLayer.isReadyForMoreMediaData,
              let buffer = currentBuffer,
              let sample = makeSampleBuffer(buffer) else { return }
        displayLayer.enqueue(sample)
    }

    private func makeSampleBuffer(_ pixelBuffer: CVPixelBuffer) -> CMSampleBuffer? {
        var formatDescription: CMVideoFormatDescription?
        CMVideoFormatDescriptionCreateForImageBuffer(allocator: kCFAllocatorDefault,
                                                     imageBuffer: pixelBuffer,
                                                     formatDescriptionOut: &formatDescription)
        guard let formatDescription = formatDescription else { return nil }

        var timing = CMSampleTimingInfo(duration: CMTime(value: 1, timescale: 30),
                                        presentationTimeStamp: CMClockGetTime(CMClockGetHostTimeClock()),
                                        decodeTimeStamp: .invalid)
        var sampleBuffer: CMSampleBuffer?
        CMSampleBufferCreateReadyWithImageBuffer(allocator: kCFAllocatorDefault,
                                                 imageBuffer: pixelBuffer,
                                                 formatDescription: formatDescription,
                                                 sampleTiming: &timing,
                                                 sampleBufferOut: &sampleBuffer)
        return sampleBuffer
    }

    /// 把最新複製的文字畫成一張 720x300（2.4:1 的扁長條）的畫面，懸浮視窗會比 16:9 矮
    private func render() -> CVPixelBuffer? {
        let width = 720
        let height = 300

        var pb: CVPixelBuffer?
        let attrs: [String: Any] = [
            kCVPixelBufferCGImageCompatibilityKey as String: true,
            kCVPixelBufferCGBitmapContextCompatibilityKey as String: true,
            kCVPixelBufferIOSurfacePropertiesKey as String: [String: Any]()
        ]
        CVPixelBufferCreate(kCFAllocatorDefault, width, height,
                            kCVPixelFormatType_32BGRA, attrs as CFDictionary, &pb)
        guard let buffer = pb else { return nil }

        CVPixelBufferLockBaseAddress(buffer, [])
        defer { CVPixelBufferUnlockBaseAddress(buffer, []) }

        guard let ctx = CGContext(
            data: CVPixelBufferGetBaseAddress(buffer),
            width: width,
            height: height,
            bitsPerComponent: 8,
            bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),
            space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGImageAlphaInfo.premultipliedFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue
        ) else { return nil }

        // 轉成 UIKit 座標（左上角為原點）
        ctx.translateBy(x: 0, y: CGFloat(height))
        ctx.scaleBy(x: 1, y: -1)
        UIGraphicsPushContext(ctx)
        defer { UIGraphicsPopContext() }

        UIColor(red: 0.11, green: 0.11, blue: 0.12, alpha: 1).setFill()
        UIRectFill(CGRect(x: 0, y: 0, width: width, height: height))

        var title = "剪貼清單"
        if let date = latestDate {
            let f = DateFormatter()
            f.timeStyle = .short
            f.dateStyle = .none
            title = "最新複製 · " + f.string(from: date)
        }
        let titleAttrs: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: 26, weight: .semibold),
            .foregroundColor: UIColor(white: 0.6, alpha: 1)
        ]
        (title as NSString).draw(at: CGPoint(x: 28, y: 22), withAttributes: titleAttrs)

        let para = NSMutableParagraphStyle()
        para.lineBreakMode = .byTruncatingTail
        let fontSize: CGFloat = latestText.count > 60 ? 34 : 48
        let bodyAttrs: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: fontSize, weight: .medium),
            .foregroundColor: UIColor.white,
            .paragraphStyle: para
        ]
        let body = String(latestText.prefix(200)) as NSString
        body.draw(with: CGRect(x: 28, y: 72, width: CGFloat(width) - 56, height: CGFloat(height) - 100),
                  options: [.usesLineFragmentOrigin, .truncatesLastVisibleLine],
                  attributes: bodyAttrs,
                  context: nil)

        return buffer
    }
}

// MARK: - PiP 播放代理（我們是「假影片」，只需要回報一直在播放）

extension PiPManager: AVPictureInPictureSampleBufferPlaybackDelegate {
    func pictureInPictureController(_ pictureInPictureController: AVPictureInPictureController, setPlaying playing: Bool) {}

    func pictureInPictureControllerTimeRangeForPlayback(_ pictureInPictureController: AVPictureInPictureController) -> CMTimeRange {
        CMTimeRange(start: .zero, duration: .positiveInfinity)
    }

    func pictureInPictureControllerIsPlaybackPaused(_ pictureInPictureController: AVPictureInPictureController) -> Bool {
        false
    }

    func pictureInPictureController(_ pictureInPictureController: AVPictureInPictureController, didTransitionToRenderSize newRenderSize: CMVideoDimensions) {}

    func pictureInPictureController(_ pictureInPictureController: AVPictureInPictureController, skipByInterval skipInterval: CMTime, completion completionHandler: @escaping () -> Void) {
        completionHandler()
    }
}

extension PiPManager: AVPictureInPictureControllerDelegate {
    func pictureInPictureControllerDidStartPictureInPicture(_ pictureInPictureController: AVPictureInPictureController) {
        isActive = true
        wantsRunning = true
        isStarting = false
        startRequested = false
    }

    func pictureInPictureControllerDidStopPictureInPicture(_ pictureInPictureController: AVPictureInPictureController) {
        isActive = false
        isStarting = false
        startRequested = false
    }

    func pictureInPictureController(_ pictureInPictureController: AVPictureInPictureController, failedToStartPictureInPictureWithError error: Error) {
        startRequested = false
        // 偶爾第一次會失敗：自動再試幾次，不要讓使用者一直重按
        if isStarting && startRetries < 3 {
            startRetries += 1
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { [weak self] in
                self?.tryStart(attempt: 0)
            }
            return
        }
        isActive = false
        isStarting = false
        message = "啟動失敗：\(error.localizedDescription)"
    }

    func pictureInPictureController(_ pictureInPictureController: AVPictureInPictureController, restoreUserInterfaceForPictureInPictureStopWithCompletionHandler completionHandler: @escaping (Bool) -> Void) {
        completionHandler(true)
    }
}

import UIKit

/// 顯示「剪貼清單」歷史的鍵盤：點一下項目就輸入到目前的輸入框
final class KeyboardViewController: UIInputViewController {
    private let tableView = UITableView(frame: .zero, style: .plain)
    private let emptyLabel = UILabel()
    private var items: [ClipItem] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        buildUI()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        reload()
    }

    // MARK: - 畫面

    private func buildUI() {
        let height = view.heightAnchor.constraint(equalToConstant: 280)
        height.priority = UILayoutPriority(999)
        height.isActive = true

        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.backgroundColor = .clear
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")

        emptyLabel.translatesAutoresizingMaskIntoConstraints = false
        emptyLabel.text = "還沒有內容。\n請先在 App 開啟「背景剪貼簿」並複製東西。\n若一直是空的，請到 設定 > 鍵盤 > 剪貼清單 開啟「允許完整取用」。"
        emptyLabel.numberOfLines = 0
        emptyLabel.textAlignment = .center
        emptyLabel.textColor = .secondaryLabel
        emptyLabel.font = .systemFont(ofSize: 14)

        let globeButton = makeButton(systemImage: "globe")
        globeButton.addTarget(self, action: #selector(handleInputModeList(from:with:)), for: .allTouchEvents)

        let spaceButton = makeButton(title: "空白")
        spaceButton.addTarget(self, action: #selector(tapSpace), for: .touchUpInside)

        let deleteButton = makeButton(systemImage: "delete.left")
        deleteButton.addTarget(self, action: #selector(tapDelete), for: .touchUpInside)

        let returnButton = makeButton(systemImage: "return")
        returnButton.addTarget(self, action: #selector(tapReturn), for: .touchUpInside)

        let bar = UIStackView(arrangedSubviews: [globeButton, spaceButton, deleteButton, returnButton])
        bar.translatesAutoresizingMaskIntoConstraints = false
        bar.axis = .horizontal
        bar.spacing = 8
        bar.distribution = .fill

        view.addSubview(tableView)
        view.addSubview(emptyLabel)
        view.addSubview(bar)

        NSLayoutConstraint.activate([
            bar.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 8),
            bar.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -8),
            bar.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -6),
            bar.heightAnchor.constraint(equalToConstant: 42),

            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: bar.topAnchor, constant: -6),

            emptyLabel.centerYAnchor.constraint(equalTo: tableView.centerYAnchor),
            emptyLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            emptyLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24),

            globeButton.widthAnchor.constraint(equalToConstant: 56),
            deleteButton.widthAnchor.constraint(equalToConstant: 56),
            returnButton.widthAnchor.constraint(equalToConstant: 56)
        ])
    }

    private func makeButton(title: String? = nil, systemImage: String? = nil) -> UIButton {
        let button = UIButton(type: .system)
        if let title = title {
            button.setTitle(title, for: .normal)
        }
        if let name = systemImage {
            button.setImage(UIImage(systemName: name), for: .normal)
        }
        button.tintColor = .label
        button.backgroundColor = .systemGray4
        button.layer.cornerRadius = 8
        return button
    }

    // MARK: - 資料

    private func reload() {
        let all = ClipFile.load()
        // 釘選的排前面，其餘照時間（最新在前）
        items = all.filter { $0.pinned } + all.filter { !$0.pinned }
        emptyLabel.isHidden = !items.isEmpty
        tableView.reloadData()
    }

    // MARK: - 按鈕

    @objc private func tapSpace() {
        textDocumentProxy.insertText(" ")
    }

    @objc private func tapDelete() {
        textDocumentProxy.deleteBackward()
    }

    @objc private func tapReturn() {
        textDocumentProxy.insertText("\n")
    }
}

// MARK: - 清單

extension KeyboardViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        items.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let item = items[indexPath.row]
        var content = cell.defaultContentConfiguration()
        content.text = (item.pinned ? "📌 " : "") + item.text
        content.textProperties.numberOfLines = 2
        cell.contentConfiguration = content
        cell.backgroundColor = .clear
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        textDocumentProxy.insertText(items[indexPath.row].text)
    }
}

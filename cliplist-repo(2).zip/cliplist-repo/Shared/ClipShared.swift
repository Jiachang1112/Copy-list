import Foundation

/// App 與鍵盤擴充共用的 App Group（兩邊要用同一個，才讀得到同一份資料）
let clipAppGroupID = "group.com.jiachang.cliplist"

struct ClipItem: Identifiable, Codable, Equatable {
    var id = UUID()
    var text: String
    var date = Date()
    var pinned = false
}

enum ClipFile {
    /// 資料檔位置：優先放在 App Group 共用資料夾；拿不到時退回 App 自己的資料夾
    static var url: URL {
        let fm = FileManager.default
        let legacyDir = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? fm.createDirectory(at: legacyDir, withIntermediateDirectories: true)
        let legacy = legacyDir.appendingPathComponent("clips.json")

        guard let group = fm.containerURL(forSecurityApplicationGroupIdentifier: clipAppGroupID) else {
            return legacy
        }
        let shared = group.appendingPathComponent("clips.json")
        // 第一次改用共用資料夾時，把舊資料搬過去
        if !fm.fileExists(atPath: shared.path), fm.fileExists(atPath: legacy.path) {
            try? fm.copyItem(at: legacy, to: shared)
        }
        return shared
    }

    static func load() -> [ClipItem] {
        guard let data = try? Data(contentsOf: url),
              let decoded = try? JSONDecoder().decode([ClipItem].self, from: data) else { return [] }
        return decoded
    }
}

import UIKit

/// 輪詢剪貼簿的 changeCount，有變動才讀內容（只看 changeCount 不會觸發貼上提示）
final class ClipboardMonitor {
    static let shared = ClipboardMonitor()

    private var timer: Timer?
    private var lastChangeCount = UIPasteboard.general.changeCount

    private init() {}

    func start() {
        guard timer == nil else { return }
        let t = Timer(timeInterval: 0.5, repeats: true) { [weak self] _ in
            self?.check()
        }
        RunLoop.main.add(t, forMode: .common)
        timer = t
        check(force: true)
    }

    func check(force: Bool = false) {
        let pb = UIPasteboard.general
        let count = pb.changeCount
        guard force || count != lastChangeCount else { return }
        lastChangeCount = count
        // 暫停記錄時，期間複製的內容不記（恢復後也不會補記）
        if UserDefaults.standard.bool(forKey: "recordingPaused") { return }
        guard pb.hasStrings || pb.hasURLs else { return }
        guard let text = pb.string ?? pb.url?.absoluteString else { return }
        ClipStore.shared.add(text)
        PiPManager.shared.show(text: text)
    }

    /// 在 App 內點選項目複製時使用（不會被當成新的複製再記錄一次）
    func copy(_ text: String) {
        UIPasteboard.general.string = text
        lastChangeCount = UIPasteboard.general.changeCount
        PiPManager.shared.show(text: text)
    }
}

import UIKit

// MARK: - 卡片

final class ClipCell: UICollectionViewCell {
    static let reuseID = "ClipCell"

    private let bar = UIView()
    private let label = UILabel()
    private let emojiLabel = UILabel()

    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = .systemBackground
        contentView.layer.cornerRadius = 12
        contentView.layer.masksToBounds = true

        bar.translatesAutoresizingMaskIntoConstraints = false

        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.lineBreakMode = .byTruncatingTail
        label.font = .systemFont(ofSize: 14)
        label.textColor = .label

        emojiLabel.translatesAutoresizingMaskIntoConstraints = false
        emojiLabel.font = .systemFont(ofSize: 12)
        emojiLabel.setContentHuggingPriority(.required, for: .horizontal)
        emojiLabel.setContentCompressionResistancePriority(.required, for: .horizontal)

        contentView.addSubview(bar)
        contentView.addSubview(label)
        contentView.addSubview(emojiLabel)

        NSLayoutConstraint.activate([
            bar.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            bar.topAnchor.constraint(equalTo: contentView.topAnchor),
            bar.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            bar.widthAnchor.constraint(equalToConstant: 4),

            emojiLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 5),
            emojiLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -6),

            label.leadingAnchor.constraint(equalTo: bar.trailingAnchor, constant: 8),
            label.trailingAnchor.constraint(equalTo: emojiLabel.leadingAnchor, constant: -4),
            label.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 6),
            label.bottomAnchor.constraint(lessThanOrEqualTo: contentView.bottomAnchor, constant: -6)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func configure(with item: ClipItem) {
        let name = item.categoryName
        bar.backgroundColor = ClipCategory.color(name)
        emojiLabel.text = ClipCategory.emoji(name)
        label.text = (item.pinned ? "📌 " : "") + item.text
    }

    override var isHighlighted: Bool {
        didSet {
            contentView.backgroundColor = isHighlighted ? .systemGray4 : .systemBackground
        }
    }
}

// MARK: - 鍵盤

/// 顯示「剪貼清單」歷史的鍵盤：
/// 卡片格狀排列、點一下就貼上；可選欄數 × 列數；可依分類篩選；可用英數字搜尋。
///
/// 資料來源（有哪個用哪個，最後合併）：
/// 1. App Group 共用檔（簽名工具有保留 App Group 時）
/// 2. 具名剪貼簿備援（App 端同步出來）
/// 3. 鍵盤自己記錄：每次鍵盤出現時，把目前剪貼簿的文字存在鍵盤自己的資料夾（需要「允許完整取用」）
final class KeyboardViewController: UIInputViewController {
    private let normalHeight: CGFloat = 310
    private let searchHeight: CGFloat = 370
    private let spacing: CGFloat = 6

    private let defaults = UserDefaults.standard

    private var columns: Int {
        get {
            let value = defaults.integer(forKey: "kb_cols")
            return (1...4).contains(value) ? value : 2
        }
        set {
            defaults.set(newValue, forKey: "kb_cols")
        }
    }

    private var rows: Int {
        get {
            let value = defaults.integer(forKey: "kb_rows")
            return (1...4).contains(value) ? value : 3
        }
        set {
            defaults.set(newValue, forKey: "kb_rows")
        }
    }

    private var allItems: [ClipItem] = []
    private var visibleItems: [ClipItem] = []
    private var selectedCategory: String? = nil
    private var diagnosticText = ""
    private var lastCollectionSize = CGSize.zero

    private var query = "" {
        didSet { applyFilter() }
    }

    private var isSearching = false {
        didSet { updateMode() }
    }

    private var heightConstraint: NSLayoutConstraint!

    private let rootStack = UIStackView()
    private let toolbar = UIStackView()
    private let spacer = UIView()
    private let queryLabel = UILabel()
    private let emptyLabel = UILabel()
    private let chipScroll = UIScrollView()
    private let chipStack = UIStackView()
    private let searchPad = UIStackView()
    private let bottomBar = UIStackView()

    private lazy var searchButton = makeButton(systemImage: "magnifyingglass")
    private lazy var colsButton = makeButton(title: "欄 2")
    private lazy var rowsButton = makeButton(title: "列 3")

    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumInteritemSpacing = spacing
        layout.minimumLineSpacing = spacing
        let view = UICollectionView(frame: .zero, collectionViewLayout: layout)
        view.backgroundColor = .clear
        view.alwaysBounceVertical = true
        view.contentInsetAdjustmentBehavior = .never
        view.dataSource = self
        view.delegate = self
        view.register(ClipCell.self, forCellWithReuseIdentifier: ClipCell.reuseID)
        return view
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        buildUI()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        reload()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let size = collectionView.bounds.size
        if size != lastCollectionSize {
            lastCollectionSize = size
            collectionView.collectionViewLayout.invalidateLayout()
        }
    }

    // MARK: - 畫面

    private func buildUI() {
        heightConstraint = view.heightAnchor.constraint(equalToConstant: normalHeight)
        heightConstraint.priority = UILayoutPriority(999)
        heightConstraint.isActive = true

        // 上方工具列：搜尋 / 欄 / 列
        searchButton.addTarget(self, action: #selector(tapSearchToggle), for: .touchUpInside)
        colsButton.addTarget(self, action: #selector(tapColumns), for: .touchUpInside)
        rowsButton.addTarget(self, action: #selector(tapRows), for: .touchUpInside)

        queryLabel.font = .systemFont(ofSize: 15)
        queryLabel.backgroundColor = .systemBackground
        queryLabel.layer.cornerRadius = 8
        queryLabel.layer.masksToBounds = true

        toolbar.axis = .horizontal
        toolbar.spacing = 6
        toolbar.distribution = .fill
        toolbar.addArrangedSubview(searchButton)
        toolbar.addArrangedSubview(colsButton)
        toolbar.addArrangedSubview(rowsButton)
        toolbar.addArrangedSubview(queryLabel)
        toolbar.addArrangedSubview(spacer)

        // 分類標籤列（橫向捲動）
        chipStack.translatesAutoresizingMaskIntoConstraints = false
        chipStack.axis = .horizontal
        chipStack.spacing = 6
        chipStack.alignment = .fill
        chipScroll.showsHorizontalScrollIndicator = false
        chipScroll.addSubview(chipStack)
        NSLayoutConstraint.activate([
            chipStack.leadingAnchor.constraint(equalTo: chipScroll.contentLayoutGuide.leadingAnchor),
            chipStack.trailingAnchor.constraint(equalTo: chipScroll.contentLayoutGuide.trailingAnchor),
            chipStack.topAnchor.constraint(equalTo: chipScroll.contentLayoutGuide.topAnchor),
            chipStack.bottomAnchor.constraint(equalTo: chipScroll.contentLayoutGuide.bottomAnchor),
            chipStack.heightAnchor.constraint(equalTo: chipScroll.frameLayoutGuide.heightAnchor)
        ])

        // 空狀態
        emptyLabel.translatesAutoresizingMaskIntoConstraints = false
        emptyLabel.numberOfLines = 0
        emptyLabel.textAlignment = .center
        emptyLabel.textColor = .secondaryLabel
        emptyLabel.font = .systemFont(ofSize: 14)

        // 搜尋用的迷你鍵盤
        buildSearchPad()

        // 下方：地球 / 空白 / 刪除 / 換行
        let globeButton = makeButton(systemImage: "globe")
        globeButton.addTarget(self, action: #selector(handleInputModeList(from:with:)), for: .allTouchEvents)
        let spaceButton = makeButton(title: "空白")
        spaceButton.addTarget(self, action: #selector(tapSpace), for: .touchUpInside)
        let deleteButton = makeButton(systemImage: "delete.left")
        deleteButton.addTarget(self, action: #selector(tapDelete), for: .touchUpInside)
        let returnButton = makeButton(systemImage: "return")
        returnButton.addTarget(self, action: #selector(tapReturn), for: .touchUpInside)

        bottomBar.axis = .horizontal
        bottomBar.spacing = 8
        bottomBar.distribution = .fill
        bottomBar.addArrangedSubview(globeButton)
        bottomBar.addArrangedSubview(spaceButton)
        bottomBar.addArrangedSubview(deleteButton)
        bottomBar.addArrangedSubview(returnButton)

        // 整體由上到下排列
        rootStack.translatesAutoresizingMaskIntoConstraints = false
        rootStack.axis = .vertical
        rootStack.spacing = 4
        rootStack.distribution = .fill
        rootStack.addArrangedSubview(toolbar)
        rootStack.addArrangedSubview(chipScroll)
        rootStack.addArrangedSubview(collectionView)
        rootStack.addArrangedSubview(searchPad)
        rootStack.addArrangedSubview(bottomBar)

        view.addSubview(rootStack)
        view.addSubview(emptyLabel)

        collectionView.setContentHuggingPriority(.defaultLow, for: .vertical)
        collectionView.setContentCompressionResistancePriority(.defaultLow, for: .vertical)
        spacer.setContentHuggingPriority(.defaultLow, for: .horizontal)
        queryLabel.setContentHuggingPriority(.defaultLow, for: .horizontal)

        NSLayoutConstraint.activate([
            rootStack.topAnchor.constraint(equalTo: view.topAnchor, constant: 4),
            rootStack.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -4),
            rootStack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 6),
            rootStack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -6),

            toolbar.heightAnchor.constraint(equalToConstant: 32),
            searchButton.widthAnchor.constraint(equalToConstant: 44),
            colsButton.widthAnchor.constraint(equalToConstant: 64),
            rowsButton.widthAnchor.constraint(equalToConstant: 64),

            chipScroll.heightAnchor.constraint(equalToConstant: 28),
            searchPad.heightAnchor.constraint(equalToConstant: 186),

            bottomBar.heightAnchor.constraint(equalToConstant: 42),
            globeButton.widthAnchor.constraint(equalToConstant: 56),
            deleteButton.widthAnchor.constraint(equalToConstant: 56),
            returnButton.widthAnchor.constraint(equalToConstant: 56),

            emptyLabel.centerYAnchor.constraint(equalTo: collectionView.centerYAnchor),
            emptyLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            emptyLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24)
        ])

        refreshLayoutButtons()
        updateMode()
    }

    private func buildSearchPad() {
        searchPad.axis = .vertical
        searchPad.spacing = 4
        searchPad.distribution = .fillEqually

        let letterRows = ["1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm"]
        for (index, letters) in letterRows.enumerated() {
            let rowStack = makeRowStack()
            for letter in letters {
                rowStack.addArrangedSubview(makeKey(title: String(letter)))
            }
            if index == letterRows.count - 1 {
                let deleteKey = makeKey(systemImage: "delete.left", special: true)
                deleteKey.addTarget(self, action: #selector(tapKeyDelete), for: .touchUpInside)
                rowStack.addArrangedSubview(deleteKey)
            }
            searchPad.addArrangedSubview(rowStack)
        }

        let symbolRow = makeRowStack()
        for symbol in [".", ",", "-", "_", ":", "/", "@"] {
            symbolRow.addArrangedSubview(makeKey(title: symbol))
        }
        symbolRow.addArrangedSubview(makeKey(title: "空白", special: true))
        searchPad.addArrangedSubview(symbolRow)
    }

    private func makeRowStack() -> UIStackView {
        let stack = UIStackView()
        stack.axis = .horizontal
        stack.spacing = 4
        stack.distribution = .fillEqually
        return stack
    }

    private func makeKey(title: String? = nil, systemImage: String? = nil, special: Bool = false) -> UIButton {
        let key = makeButton(title: title, systemImage: systemImage)
        key.titleLabel?.font = .systemFont(ofSize: 17)
        key.backgroundColor = special ? .systemGray3 : .systemBackground
        if title != nil {
            key.addTarget(self, action: #selector(tapKey(_:)), for: .touchUpInside)
        }
        return key
    }

    private func makeButton(title: String? = nil, systemImage: String? = nil) -> UIButton {
        let button = UIButton(type: .system)
        if let title = title {
            button.setTitle(title, for: .normal)
        }
        if let name = systemImage {
            button.setImage(UIImage(systemName: name), for: .normal)
        }
        button.tintColor = .label
        button.backgroundColor = .systemGray4
        button.layer.cornerRadius = 8
        return button
    }

    /// 切換「一般 / 搜尋」兩種畫面
    private func updateMode() {
        searchPad.isHidden = !isSearching
        bottomBar.isHidden = isSearching
        chipScroll.isHidden = isSearching
        queryLabel.isHidden = !isSearching
        spacer.isHidden = isSearching
        colsButton.isHidden = isSearching
        rowsButton.isHidden = isSearching
        heightConstraint.constant = isSearching ? searchHeight : normalHeight
        let icon = isSearching ? "xmark" : "magnifyingglass"
        searchButton.setImage(UIImage(systemName: icon), for: .normal)
        query = ""
        applyFilter()
    }

    private func refreshLayoutButtons() {
        colsButton.setTitle("欄 \(columns)", for: .normal)
        rowsButton.setTitle("列 \(rows)", for: .normal)
        collectionView.collectionViewLayout.invalidateLayout()
    }

    // MARK: - 分類標籤

    private func rebuildChips() {
        for chip in chipStack.arrangedSubviews {
            chipStack.removeArrangedSubview(chip)
            chip.removeFromSuperview()
        }

        let summary = ClipCategory.summary(of: allItems)
        if let selected = selectedCategory, !summary.contains(where: { $0.name == selected }) {
            selectedCategory = nil
        }

        chipStack.addArrangedSubview(makeChip(title: "✨ 全部 \(allItems.count)", name: nil, tint: .systemGreen))
        for entry in summary {
            let title = ClipCategory.emoji(entry.name) + " " + entry.name + " \(entry.count)"
            chipStack.addArrangedSubview(makeChip(title: title, name: entry.name, tint: ClipCategory.color(entry.name)))
        }
    }

    private func makeChip(title: String, name: String?, tint: UIColor) -> UIButton {
        let selected = (selectedCategory == name)
        let chip = UIButton(type: .custom)
        chip.setTitle(title, for: .normal)
        chip.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        chip.setTitleColor(selected ? .white : .label, for: .normal)
        chip.backgroundColor = selected ? tint : .systemBackground
        chip.layer.cornerRadius = 14
        chip.contentEdgeInsets = UIEdgeInsets(top: 4, left: 10, bottom: 4, right: 10)
        chip.addAction(UIAction { [weak self] _ in
            self?.selectCategory(name)
        }, for: .touchUpInside)
        return chip
    }

    private func selectCategory(_ name: String?) {
        selectedCategory = name
        rebuildChips()
        applyFilter()
    }

    // MARK: - 資料

    private func reload() {
        captureGeneralPasteboard()

        let fileItems = ClipFile.loadFile()
        let pasteboardItems = ClipShare.loadFromPasteboard()
        let own = loadOwn()

        var merged = fileItems.isEmpty ? pasteboardItems : fileItems
        for item in own where !merged.contains(where: { $0.text == item.text }) {
            merged.append(item)
        }

        // 釘選的排前面，其餘照時間（最新在前）
        allItems = merged.sorted { a, b in
            if a.pinned != b.pinned { return a.pinned }
            return a.date > b.date
        }

        let access = hasFullAccess ? "開" : "關"
        let group = ClipFile.groupAvailable ? "有" : "無"
        diagnosticText = "診斷：完整取用\(access)｜App Group\(group)｜共用檔\(fileItems.count)｜備援\(pasteboardItems.count)｜本機\(own.count)"

        rebuildChips()
        applyFilter()
    }

    private func applyFilter() {
        let keyword = query.trimmingCharacters(in: .whitespaces)
        let category: String? = isSearching ? nil : selectedCategory

        visibleItems = allItems.filter { item in
            if let category = category, item.categoryName != category { return false }
            if !keyword.isEmpty && !item.text.localizedCaseInsensitiveContains(keyword) { return false }
            return true
        }

        queryLabel.text = "  " + (query.isEmpty ? "輸入英數字搜尋…" : query)
        queryLabel.textColor = query.isEmpty ? .tertiaryLabel : .label

        if allItems.isEmpty {
            emptyLabel.text = "還沒有內容。\n先在任何 App 複製文字，再切到這個鍵盤就會記錄。\n（需要開啟「允許完整取用」）\n\n" + diagnosticText
        } else {
            emptyLabel.text = "找不到符合的項目"
        }
        emptyLabel.isHidden = !visibleItems.isEmpty
        collectionView.reloadData()
    }

    // MARK: - 鍵盤自己記錄剪貼簿

    private var ownFileURL: URL {
        let fm = FileManager.default
        let dir = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent("keyboard_clips.json")
    }

    private func loadOwn() -> [ClipItem] {
        guard let data = try? Data(contentsOf: ownFileURL),
              let decoded = try? JSONDecoder().decode([ClipItem].self, from: data) else { return [] }
        return decoded
    }

    private func saveOwn(_ list: [ClipItem]) {
        guard let data = try? JSONEncoder().encode(list) else { return }
        try? data.write(to: ownFileURL, options: .atomic)
    }

    private func captureGeneralPasteboard() {
        guard hasFullAccess else { return }
        let pb = UIPasteboard.general
        guard pb.hasStrings, let text = pb.string,
              !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }

        var own = loadOwn()
        if let index = own.firstIndex(where: { $0.text == text }) {
            var item = own.remove(at: index)
            item.date = Date()
            own.insert(item, at: 0)
        } else {
            own.insert(ClipItem(text: text), at: 0)
        }
        saveOwn(Array(own.prefix(100)))
    }

    // MARK: - 按鈕

    @objc private func tapSearchToggle() {
        isSearching.toggle()
    }

    @objc private func tapColumns() {
        columns = columns % 4 + 1
        refreshLayoutButtons()
    }

    @objc private func tapRows() {
        rows = rows % 4 + 1
        refreshLayoutButtons()
    }

    @objc private func tapKey(_ sender: UIButton) {
        guard let key = sender.title(for: .normal) else { return }
        query += (key == "空白") ? " " : key
    }

    @objc private func tapKeyDelete() {
        if !query.isEmpty {
            query.removeLast()
        }
    }

    @objc private func tapSpace() {
        textDocumentProxy.insertText(" ")
    }

    @objc private func tapDelete() {
        textDocumentProxy.deleteBackward()
    }

    @objc private func tapReturn() {
        textDocumentProxy.insertText("\n")
    }
}

// MARK: - 格狀清單

extension KeyboardViewController: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        visibleItems.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ClipCell.reuseID, for: indexPath) as? ClipCell else {
            return UICollectionViewCell()
        }
        cell.configure(with: visibleItems[indexPath.item])
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        textDocumentProxy.insertText(visibleItems[indexPath.item].text)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let cols = CGFloat(columns)
        let rowCount = CGFloat(rows)
        let width = floor((collectionView.bounds.width - spacing * (cols - 1)) / cols)
        let height = floor((collectionView.bounds.height - spacing * (rowCount - 1)) / rowCount)
        return CGSize(width: max(width, 30), height: max(height, 30))
    }
}

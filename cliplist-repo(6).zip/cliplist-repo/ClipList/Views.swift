import SwiftUI
import UIKit

// MARK: - 主畫面

struct ContentView: View {
    @ObservedObject private var pip = PiPManager.shared
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        ZStack(alignment: .bottom) {
            TabView {
                HistoryView(pinnedOnly: false)
                    .tabItem { Label("剪貼簿", systemImage: "doc.on.clipboard") }
                HistoryView(pinnedOnly: true)
                    .tabItem { Label("常用", systemImage: "pin") }
                SettingsView()
                    .tabItem { Label("設定", systemImage: "gearshape") }
            }
            .tint(Color.green)

            recordButton

            // 懸浮視窗的影像層需要掛在畫面上（幾乎透明，不會看到）
            PiPHostView()
                .frame(width: 32, height: 18)
                .opacity(0.02)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                .allowsHitTesting(false)
        }
        .onChange(of: scenePhase) { phase in
            if phase == .active { ClipboardMonitor.shared.check() }
        }
        .alert("提示", isPresented: Binding(
            get: { pip.message != nil },
            set: { if !$0 { pip.message = nil } }
        )) {
            Button("好", role: .cancel) {}
        } message: {
            Text(pip.message ?? "")
        }
    }

    private var recordButton: some View {
        let colors: [Color] = pip.isActive ? [Color.red, Color.orange] : [Color.green, Color.teal]
        return Button {
            if pip.isActive { pip.stop() } else { pip.start() }
        } label: {
            HStack(spacing: 8) {
                Image(systemName: pip.isActive ? "stop.fill" : "play.fill")
                Text(pip.isActive ? "關閉背景剪貼簿" : "開啟背景剪貼簿")
            }
            .font(.subheadline.weight(.semibold))
            .foregroundStyle(.white)
            .padding(.horizontal, 20)
            .padding(.vertical, 12)
            .background(
                Capsule().fill(
                    LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing)
                )
            )
        }
        .shadow(color: .black.opacity(0.25), radius: 8, y: 3)
        .padding(.bottom, 64)
    }
}

// MARK: - 歷史清單

struct HistoryView: View {
    @ObservedObject private var store = ClipStore.shared
    @Environment(\.openURL) private var openURL
    let pinnedOnly: Bool

    @State private var query = ""
    @State private var selectedCategory: String? = nil
    @State private var showToast = false
    @State private var showNewCategory = false
    @State private var newCategoryName = ""
    @State private var itemForNewCategory: ClipItem? = nil

    /// 這一頁的範圍（「常用」頁只看釘選的）
    private var scoped: [ClipItem] {
        store.items.filter { !pinnedOnly || $0.pinned }
    }

    private var categories: [(name: String, count: Int)] {
        ClipCategory.summary(of: scoped)
    }

    /// 目前選中的分類；如果那個分類已經沒有項目就回到「全部」
    private var activeCategory: String? {
        guard let selected = selectedCategory,
              categories.contains(where: { $0.name == selected }) else { return nil }
        return selected
    }

    private var filtered: [ClipItem] {
        scoped.filter { item in
            if let category = activeCategory, item.categoryName != category { return false }
            if !query.isEmpty && !item.text.localizedCaseInsensitiveContains(query) { return false }
            return true
        }
    }

    private var groups: [(day: Date, items: [ClipItem])] {
        let cal = Calendar.current
        let dict = Dictionary(grouping: filtered) { cal.startOfDay(for: $0.date) }
        return dict.keys.sorted(by: >).map { day in
            (day: day, items: (dict[day] ?? []).sorted { $0.date > $1.date })
        }
    }

    /// 「移到分類」可選的名稱：已有的分類 + 還沒用到的預設分類
    private var categoryChoices: [String] {
        let existing = ClipCategory.summary(of: store.items).map { $0.name }
        let unused = ClipCategory.defaultNames.filter { !existing.contains($0) }
        return existing + unused
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                if !categories.isEmpty {
                    chipBar
                }
                itemList
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle(pinnedOnly ? "常用" : "剪貼簿")
            .searchable(text: $query, prompt: "搜尋內容")
            .overlay(alignment: .top) { toast }
            .alert("新增分類", isPresented: $showNewCategory) {
                TextField("分類名稱", text: $newCategoryName)
                Button("取消", role: .cancel) { itemForNewCategory = nil }
                Button("確定") { applyNewCategory() }
            } message: {
                Text("把這筆內容放進新的分類")
            }
        }
    }

    // MARK: 分類標籤列

    private var chipBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                chip(title: "全部", emoji: "✨", count: scoped.count,
                     tint: Color.green, selected: activeCategory == nil) {
                    selectedCategory = nil
                }
                ForEach(categories, id: \.name) { entry in
                    chip(title: entry.name, emoji: ClipCategory.emoji(entry.name), count: entry.count,
                         tint: Color(uiColor: ClipCategory.color(entry.name)),
                         selected: activeCategory == entry.name) {
                        selectedCategory = entry.name
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
        }
    }

    private func chip(title: String, emoji: String, count: Int, tint: Color,
                      selected: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 4) {
                Text(emoji)
                Text(title).bold()
                Text("\(count)")
                    .foregroundStyle(selected ? Color.white.opacity(0.85) : Color.secondary)
            }
            .font(.footnote)
            .foregroundStyle(selected ? Color.white : Color.primary)
            .padding(.horizontal, 12)
            .padding(.vertical, 7)
            .background(
                Capsule().fill(selected ? tint : Color(uiColor: .secondarySystemGroupedBackground))
            )
        }
        .buttonStyle(.plain)
    }

    // MARK: 清單

    private var itemList: some View {
        List {
            ForEach(groups, id: \.day) { group in
                Section {
                    ForEach(group.items) { item in
                        itemRow(item)
                    }
                } header: {
                    Text(group.day, format: .dateTime.year().month().day())
                }
            }
        }
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
        .overlay { emptyState }
        .safeAreaInset(edge: .bottom) {
            Color.clear.frame(height: 60)
        }
    }

    @ViewBuilder
    private var emptyState: some View {
        if groups.isEmpty {
            VStack(spacing: 10) {
                Image(systemName: pinnedOnly ? "pin.slash" : "doc.on.clipboard")
                    .font(.system(size: 44))
                    .foregroundStyle(.tertiary)
                Text(pinnedOnly ? "左滑項目即可釘選" : "還沒有內容，去複製些東西吧")
                    .foregroundStyle(.secondary)
            }
        }
    }

    private func itemRow(_ item: ClipItem) -> some View {
        Button { copy(item) } label: { rowCard(item) }
            .buttonStyle(.plain)
            .listRowSeparator(.hidden)
            .listRowBackground(Color.clear)
            .listRowInsets(EdgeInsets(top: 4, leading: 16, bottom: 4, trailing: 16))
            .swipeActions(edge: .trailing) {
                Button(role: .destructive) {
                    store.delete(item)
                } label: {
                    Label("刪除", systemImage: "trash")
                }
            }
            .swipeActions(edge: .leading) {
                Button {
                    store.togglePin(item)
                } label: {
                    Label(item.pinned ? "取消釘選" : "釘選", systemImage: "pin")
                }
                .tint(.orange)
            }
            .contextMenu { menuItems(item) }
    }

    private func rowCard(_ item: ClipItem) -> some View {
        let name = item.categoryName
        let tint = Color(uiColor: ClipCategory.color(name))
        return HStack(alignment: .top, spacing: 12) {
            Text(ClipCategory.emoji(name))
                .font(.title3)
                .frame(width: 40, height: 40)
                .background(tint.opacity(0.15), in: RoundedRectangle(cornerRadius: 12, style: .continuous))

            VStack(alignment: .leading, spacing: 6) {
                Text(item.text)
                    .font(.body)
                    .lineLimit(3)
                    .multilineTextAlignment(.leading)

                HStack(spacing: 6) {
                    Text(name)
                        .font(.caption2.bold())
                        .foregroundStyle(tint)
                        .padding(.horizontal, 7)
                        .padding(.vertical, 2)
                        .background(tint.opacity(0.12), in: Capsule())
                    Text(item.date, style: .time)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    if item.pinned {
                        Image(systemName: "pin.fill")
                            .font(.caption)
                            .foregroundStyle(.orange)
                    }
                }
            }
            Spacer(minLength: 0)
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            Color(uiColor: .secondarySystemGroupedBackground),
            in: RoundedRectangle(cornerRadius: 16, style: .continuous)
        )
        .contentShape(Rectangle())
    }

    // MARK: 長按選單

    @ViewBuilder
    private func menuItems(_ item: ClipItem) -> some View {
        Button { copy(item) } label: {
            Label("複製", systemImage: "doc.on.doc")
        }
        Button { store.togglePin(item) } label: {
            Label(item.pinned ? "取消釘選" : "釘選", systemImage: item.pinned ? "pin.slash" : "pin")
        }

        if let link = item.linkURL {
            Button { openURL(link) } label: {
                Label("開啟連結", systemImage: "safari")
            }
        }
        if let coord = item.coordinate {
            Button { openMap(coord) } label: {
                Label("在地圖開啟", systemImage: "map")
            }
        }

        ShareLink(item: item.text) {
            Label("分享", systemImage: "square.and.arrow.up")
        }

        Menu {
            ForEach(categoryChoices, id: \.self) { name in
                Button(ClipCategory.emoji(name) + " " + name) {
                    store.setCategory(item, to: name)
                }
            }
            Button("新增分類…") {
                itemForNewCategory = item
                newCategoryName = ""
                showNewCategory = true
            }
            if item.category != nil {
                Button("恢復自動分類") {
                    store.setCategory(item, to: nil)
                }
            }
        } label: {
            Label("移到分類", systemImage: "folder")
        }

        Button(role: .destructive) { store.delete(item) } label: {
            Label("刪除", systemImage: "trash")
        }
    }

    // MARK: 動作

    @ViewBuilder
    private var toast: some View {
        if showToast {
            Text("已複製")
                .font(.subheadline.bold())
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
                .background(.ultraThinMaterial, in: Capsule())
                .padding(.top, 8)
                .transition(.opacity)
        }
    }

    private func applyNewCategory() {
        if let item = itemForNewCategory {
            store.setCategory(item, to: newCategoryName)
        }
        itemForNewCategory = nil
    }

    private func openMap(_ coord: (lat: Double, lon: Double)) {
        if let url = URL(string: "http://maps.apple.com/?ll=\(coord.lat),\(coord.lon)") {
            openURL(url)
        }
    }

    private func copy(_ item: ClipItem) {
        ClipboardMonitor.shared.copy(item.text)
        UINotificationFeedbackGenerator().notificationOccurred(.success)
        withAnimation { showToast = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            withAnimation { showToast = false }
        }
    }
}

// MARK: - 設定

struct SettingsView: View {
    @ObservedObject private var store = ClipStore.shared
    @ObservedObject private var pip = PiPManager.shared

    private var groupText: String {
        ClipFile.groupAvailable ? "可用" : "不可用（簽名工具沒保留）"
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Toggle("背景剪貼簿（懸浮視窗）", isOn: Binding(
                        get: { pip.isActive },
                        set: { $0 ? pip.start() : pip.stop() }
                    ))
                } header: {
                    Text("背景擷取")
                } footer: {
                    Text("開啟後會出現一個小視窗，切到其他 App 也會繼續記錄你複製的內容。")
                }

                Section {
                    Button {
                        if let url = URL(string: UIApplication.openSettingsURLString) {
                            UIApplication.shared.open(url)
                        }
                    } label: {
                        Label("開啟 iOS 設定", systemImage: "hand.raised")
                    }
                } header: {
                    Text("貼上權限")
                } footer: {
                    Text("到「剪貼清單 > 從其他 App 貼上」選「允許」，否則每次複製都會跳出貼上提示。")
                }

                Section {
                    Text("到 iOS 設定 > 一般 > 鍵盤 > 鍵盤 > 新增鍵盤，選「剪貼清單」，再開啟「允許完整取用」。輸入時按地球鍵切換；點一下卡片就貼上。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                } header: {
                    Text("鍵盤使用說明")
                }

                Section {
                    Text("App Group：" + groupText)
                    Text("已記錄：\(store.items.count) 筆")
                } header: {
                    Text("鍵盤共用狀態")
                } footer: {
                    Text("App Group 不可用時，鍵盤會改走備援，並在你切到鍵盤時自己記錄剪貼簿。")
                }

                Section {
                    Stepper("最多保留 \(store.maxItems) 筆", value: $store.maxItems, in: 20...1000, step: 20)
                    Button("清除全部（保留釘選）", role: .destructive) {
                        store.clearUnpinned()
                    }
                } header: {
                    Text("儲存")
                }
            }
            .navigationTitle("設定")
        }
    }
}

// MARK: - 懸浮視窗影像層的容器

struct PiPHostView: UIViewRepresentable {
    func makeUIView(context: Context) -> PiPContainerView {
        PiPContainerView()
    }

    func updateUIView(_ uiView: PiPContainerView, context: Context) {}
}

final class PiPContainerView: UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        isUserInteractionEnabled = false
        layer.addSublayer(PiPManager.shared.displayLayer)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        PiPManager.shared.displayLayer.frame = bounds
    }
}

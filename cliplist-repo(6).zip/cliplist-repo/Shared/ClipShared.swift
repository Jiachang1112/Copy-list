import Foundation
import UIKit

/// App 與鍵盤擴充共用的 App Group（兩邊要用同一個，才讀得到同一份資料）
let clipAppGroupID = "group.com.jiachang.cliplist"

struct ClipItem: Identifiable, Codable, Equatable {
    var id = UUID()
    var text: String
    var date = Date()
    var pinned = false
    /// 使用者手動指定的分類；沒指定（nil）就依內容自動判斷
    var category: String? = nil
}

// MARK: - 自動分類

enum ClipKind: String, CaseIterable {
    case coordinate = "座標"
    case url = "網址"
    case email = "信箱"
    case phone = "電話"
    case number = "數字"
    case text = "文字"

    private static var cache: [String: ClipKind] = [:]
    private static let lock = NSLock()

    static func detect(_ raw: String) -> ClipKind {
        lock.lock()
        if let hit = cache[raw] {
            lock.unlock()
            return hit
        }
        lock.unlock()

        let result = compute(raw)

        lock.lock()
        if cache.count > 3000 { cache.removeAll() }
        cache[raw] = result
        lock.unlock()
        return result
    }

    private static func compute(_ raw: String) -> ClipKind {
        let s = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if s.isEmpty { return .text }
        let lower = s.lowercased()

        if s.range(of: #"^-?\d{1,3}\.\d+\s*[,，\s]\s*-?\d{1,3}\.\d+$"#, options: .regularExpression) != nil {
            return .coordinate
        }
        if !s.contains(" ") && (lower.hasPrefix("http://") || lower.hasPrefix("https://") || lower.hasPrefix("www.")) {
            return .url
        }
        if s.range(of: #"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$"#, options: .regularExpression) != nil {
            return .email
        }
        if s.range(of: #"^(\+\d[\d\s\-()]{6,18}|0\d[\d\s\-()]{6,14})$"#, options: .regularExpression) != nil {
            return .phone
        }
        if s.range(of: #"^[+\-]?[\d,.\s]+$"#, options: .regularExpression) != nil,
           s.rangeOfCharacter(from: .decimalDigits) != nil {
            return .number
        }
        return .text
    }
}

extension ClipItem {
    var kind: ClipKind { ClipKind.detect(text) }

    /// 顯示用的分類名稱：手動指定的優先，否則用自動判斷
    var categoryName: String { category ?? kind.rawValue }

    /// 內容是「緯度,經度」時回傳數值
    var coordinate: (lat: Double, lon: Double)? {
        guard kind == .coordinate else { return nil }
        let separators = CharacterSet(charactersIn: ",， \t\n")
        let parts = text.components(separatedBy: separators).filter { !$0.isEmpty }
        guard parts.count == 2, let lat = Double(parts[0]), let lon = Double(parts[1]) else { return nil }
        return (lat: lat, lon: lon)
    }

    /// 內容是網址時回傳 URL
    var linkURL: URL? {
        guard kind == .url else { return nil }
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.lowercased().hasPrefix("www.") {
            return URL(string: "https://" + trimmed)
        }
        return URL(string: trimmed)
    }
}

// MARK: - 分類的外觀與統計

enum ClipCategory {
    static let defaultNames: [String] = ClipKind.allCases.map { $0.rawValue }

    static func emoji(_ name: String) -> String {
        switch name {
        case "座標": return "📍"
        case "網址": return "🔗"
        case "信箱": return "✉️"
        case "電話": return "📞"
        case "數字": return "🔢"
        case "文字": return "📝"
        default: return "🏷️"
        }
    }

    static func color(_ name: String) -> UIColor {
        switch name {
        case "座標": return UIColor(red: 0.92, green: 0.29, blue: 0.36, alpha: 1)
        case "網址": return UIColor(red: 0.20, green: 0.52, blue: 0.96, alpha: 1)
        case "信箱": return UIColor(red: 0.96, green: 0.58, blue: 0.16, alpha: 1)
        case "電話": return UIColor(red: 0.20, green: 0.72, blue: 0.45, alpha: 1)
        case "數字": return UIColor(red: 0.58, green: 0.38, blue: 0.90, alpha: 1)
        case "文字": return UIColor(red: 0.45, green: 0.52, blue: 0.58, alpha: 1)
        default:
            // 自訂分類：依名稱挑一個固定的顏色（同名永遠同色）
            let palette: [UIColor] = [
                UIColor(red: 0.00, green: 0.66, blue: 0.68, alpha: 1),
                UIColor(red: 0.90, green: 0.36, blue: 0.62, alpha: 1),
                UIColor(red: 0.45, green: 0.55, blue: 0.95, alpha: 1),
                UIColor(red: 0.80, green: 0.62, blue: 0.10, alpha: 1),
                UIColor(red: 0.35, green: 0.68, blue: 0.30, alpha: 1)
            ]
            var hash = 0
            for scalar in name.unicodeScalars {
                hash = (hash &* 31 &+ Int(scalar.value)) % 1_000_003
            }
            return palette[hash % palette.count]
        }
    }

    /// 每個分類有幾筆（預設分類排前面，自訂分類依名稱排序）
    static func summary(of items: [ClipItem]) -> [(name: String, count: Int)] {
        var counts: [String: Int] = [:]
        for item in items {
            counts[item.categoryName, default: 0] += 1
        }
        let defaults = defaultNames.filter { counts[$0] != nil }
        let customs = counts.keys.filter { !defaultNames.contains($0) }.sorted()
        return (defaults + customs).map { (name: $0, count: counts[$0] ?? 0) }
    }
}

enum ClipFile {
    /// 資料檔位置：優先放在 App Group 共用資料夾；拿不到時退回 App 自己的資料夾
    static var url: URL {
        let fm = FileManager.default
        let legacyDir = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? fm.createDirectory(at: legacyDir, withIntermediateDirectories: true)
        let legacy = legacyDir.appendingPathComponent("clips.json")

        guard let group = fm.containerURL(forSecurityApplicationGroupIdentifier: clipAppGroupID) else {
            return legacy
        }
        let shared = group.appendingPathComponent("clips.json")
        // 第一次改用共用資料夾時，把舊資料搬過去
        if !fm.fileExists(atPath: shared.path), fm.fileExists(atPath: legacy.path) {
            try? fm.copyItem(at: legacy, to: shared)
        }
        return shared
    }

    /// App Group 是否可用（簽名工具有沒有保留）
    static var groupAvailable: Bool {
        FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: clipAppGroupID) != nil
    }

    /// 只讀資料檔（App Group 共用檔，或沒有 App Group 時是 App 自己的檔）
    static func loadFile() -> [ClipItem] {
        guard let data = try? Data(contentsOf: url),
              let decoded = try? JSONDecoder().decode([ClipItem].self, from: data) else { return [] }
        return decoded
    }
}

/// 備援通道：不靠 App Group，改用自訂名稱的剪貼簿在 App 與鍵盤之間傳資料。
/// 不影響一般剪貼簿的內容；鍵盤端需要「允許完整取用」才讀得到。
enum ClipShare {
    private static let pasteboardName = UIPasteboard.Name(rawValue: "com.jiachang.cliplist.shared")
    private static let pasteboardType = "com.jiachang.cliplist.json"

    /// App 端：把目前的清單同步出去
    static func publish(_ data: Data) {
        guard let pb = UIPasteboard(name: pasteboardName, create: true) else { return }
        pb.setData(data, forPasteboardType: pasteboardType)
    }

    /// 鍵盤端：讀取 App 同步出來的清單
    static func loadFromPasteboard() -> [ClipItem] {
        guard let pb = UIPasteboard(name: pasteboardName, create: false),
              let data = pb.data(forPasteboardType: pasteboardType),
              let decoded = try? JSONDecoder().decode([ClipItem].self, from: data) else { return [] }
        return decoded
    }
}

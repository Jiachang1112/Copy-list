import SwiftUI
import UIKit
import UniformTypeIdentifiers

// MARK: - 主畫面

/// 跨畫面的小狀態：清單進入「選取模式」時，浮動的開啟按鈕要讓開，不然會蓋住底下的操作列
final class UIState: ObservableObject {
    static let shared = UIState()
    @Published var selecting = false
}

struct ContentView: View {
    @ObservedObject private var pip = PiPManager.shared
    @ObservedObject private var lock = AppLock.shared
    @ObservedObject private var store = ClipStore.shared
    @ObservedObject private var ui = UIState.shared
    @AppStorage("lockEnabled") private var lockEnabled = false
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        ZStack(alignment: .bottom) {
            TabView {
                HistoryView(pinnedOnly: false)
                    .tabItem { Label("剪貼簿", systemImage: "doc.on.clipboard") }
                HistoryView(pinnedOnly: true)
                    .tabItem { Label("常用", systemImage: "pin") }
                SettingsView()
                    .tabItem { Label("設定", systemImage: "gearshape") }
            }
            .tint(Color.green)

            if !ui.selecting {
                recordButton
            }
            undoBar

            // 懸浮視窗的影像層需要掛在畫面上（幾乎透明，不會看到）
            PiPHostView()
                .frame(width: 32, height: 18)
                .opacity(0.02)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                .allowsHitTesting(false)
        }
        .overlay {
            // 不在前景時也先蓋住，避免「切換 App」的縮圖露出內容
            if lock.isLocked || (lockEnabled && scenePhase != .active) {
                LockScreenView()
            }
        }
        .onAppear {
            PiPManager.shared.prepare()
            if lock.isLocked { lock.unlock() }
        }
        .onChange(of: scenePhase) { phase in
            if phase == .active {
                PiPManager.shared.prepare()
                ClipboardMonitor.shared.check()
                if lock.isLocked { lock.unlock() }
            } else {
                // 離開畫面時，如果沒有在用懸浮視窗，就把它拆掉（避免系統在背景自己開）
                PiPManager.shared.teardownIfIdle()
                if phase == .background { lock.lockIfNeeded() }
            }
        }
        .alert("提示", isPresented: Binding(
            get: { pip.message != nil },
            set: { if !$0 { pip.message = nil } }
        )) {
            Button("好", role: .cancel) {}
        } message: {
            Text(pip.message ?? "")
        }
    }

    private var recordButton: some View {
        let colors: [Color] = pip.isActive ? [Color.red, Color.orange] : [Color.green, Color.teal]
        return VStack(spacing: 8) {
            if pip.wantsRunning && !pip.isActive {
                Text("⚠️ 背景記錄已停止，點下方按鈕重新開啟")
                    .font(.caption.bold())
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(Color.orange.opacity(0.9), in: Capsule())
                    .foregroundStyle(.white)
            }
            startStopButton(colors: colors)
        }
        .padding(.bottom, 64)
    }

    @ViewBuilder
    private var undoBar: some View {
        if !store.undoItems.isEmpty {
            HStack(spacing: 12) {
                Text("已刪除 \(store.undoItems.count) 筆")
                    .font(.subheadline)
                Button("復原") { store.undoDelete() }
                    .font(.subheadline.bold())
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background(.ultraThinMaterial, in: Capsule())
            .padding(.bottom, 124)
            .transition(.opacity)
        }
    }

    private var buttonIcon: String {
        if pip.isActive { return "stop.fill" }
        if pip.isStarting { return "hourglass" }
        return "play.fill"
    }

    private var buttonTitle: String {
        if pip.isActive { return "關閉背景剪貼簿" }
        if pip.isStarting { return "啟動中…" }
        return "開啟背景剪貼簿"
    }

    private func startStopButton(colors: [Color]) -> some View {
        Button {
            if pip.isStarting { return }
            if pip.isActive { pip.stop() } else { pip.start() }
        } label: {
            HStack(spacing: 8) {
                Image(systemName: buttonIcon)
                Text(buttonTitle)
            }
            .font(.subheadline.weight(.semibold))
            .foregroundStyle(.white)
            .padding(.horizontal, 20)
            .padding(.vertical, 12)
            .background(
                Capsule().fill(
                    LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing)
                )
            )
        }
        .shadow(color: .black.opacity(0.25), radius: 8, y: 3)
    }
}

// MARK: - 歷史清單

private enum ActiveSheet: Identifiable {
    case add
    case edit(ClipItem)
    case detail(ClipItem)

    var id: String {
        switch self {
        case .add: return "add"
        case .edit(let item): return "edit-" + item.id.uuidString
        case .detail(let item): return "detail-" + item.id.uuidString
        }
    }
}

struct HistoryView: View {
    @ObservedObject private var store = ClipStore.shared
    @Environment(\.openURL) private var openURL
    let pinnedOnly: Bool

    @State private var query = ""
    @State private var selectedCategory: String? = nil
    @State private var showToast = false
    @State private var showNewCategory = false
    @State private var newCategoryName = ""
    @State private var itemForNewCategory: ClipItem? = nil
    @State private var activeSheet: ActiveSheet? = nil
    @State private var renamingCategory: String? = nil
    @State private var renameText = ""
    @State private var showRenameCategory = false
    @State private var selecting = false
    @State private var selectedIDs: Set<UUID> = []
    @AppStorage("sortMode") private var sortMode = 0

    /// 這一頁的範圍（「常用」頁只看釘選的）
    private var scoped: [ClipItem] {
        store.items.filter { !pinnedOnly || $0.pinned }
    }

    private var categories: [(name: String, count: Int)] {
        ClipCategory.summary(of: scoped)
    }

    /// 目前選中的分類；如果那個分類已經沒有項目就回到「全部」
    private var activeCategory: String? {
        guard let selected = selectedCategory,
              categories.contains(where: { $0.name == selected }) else { return nil }
        return selected
    }

    private var filtered: [ClipItem] {
        scoped.filter { item in
            if let category = activeCategory, item.categoryName != category { return false }
            if !query.isEmpty && !item.text.localizedCaseInsensitiveContains(query) { return false }
            return true
        }
    }

    private var groups: [(day: Date, items: [ClipItem])] {
        let cal = Calendar.current
        let dict = Dictionary(grouping: filtered) { cal.startOfDay(for: $0.date) }
        return dict.keys.sorted(by: >).map { day in
            (day: day, items: (dict[day] ?? []).sorted { $0.date > $1.date })
        }
    }

    /// 「常用優先」：依使用次數，其次依時間
    private var frequentItems: [ClipItem] {
        filtered.sorted { a, b in
            if a.uses != b.uses { return a.uses > b.uses }
            return a.date > b.date
        }
    }

    /// 「移到分類」可選的名稱：已有的分類 + 還沒用到的預設分類
    private var categoryChoices: [String] {
        let existing = ClipCategory.summary(of: store.items).map { $0.name }
        let unused = ClipCategory.defaultNames.filter { !existing.contains($0) }
        return existing + unused
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                if !categories.isEmpty {
                    chipBar
                }
                itemList
                    .alert("重新命名分類", isPresented: $showRenameCategory) {
                        TextField("分類名稱", text: $renameText)
                        Button("取消", role: .cancel) { renamingCategory = nil }
                        Button("確定") { applyRenameCategory() }
                    }
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle(pinnedOnly ? "常用" : "剪貼簿")
            .searchable(text: $query, prompt: "搜尋內容")
            .overlay(alignment: .top) { toast }
            .alert("新增分類", isPresented: $showNewCategory) {
                TextField("分類名稱", text: $newCategoryName)
                Button("取消", role: .cancel) { itemForNewCategory = nil }
                Button("確定") { applyNewCategory() }
            } message: {
                Text("把這筆內容放進新的分類")
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(selecting ? "完成" : "選取") {
                        selecting.toggle()
                        selectedIDs = []
                    }
                }
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    sortMenu
                    Button {
                        activeSheet = .add
                    } label: {
                        Image(systemName: "plus.circle.fill")
                    }
                }
            }
            .sheet(item: $activeSheet) { sheet in
                sheetContent(sheet)
            }
            .onChange(of: selecting) { value in
                UIState.shared.selecting = value
            }
            .onDisappear {
                selecting = false
                selectedIDs = []
            }
        }
    }

    @ViewBuilder
    private func sheetContent(_ sheet: ActiveSheet) -> some View {
        switch sheet {
        case .add:
            TextEditorSheet(title: "新增片語", initialText: "", categoryChoices: categoryChoices) { text, category in
                store.addManual(text, category: category)
            }
            .presentationDetents([.medium, .large])
        case .edit(let item):
            TextEditorSheet(title: "編輯內容", initialText: item.text, categoryChoices: []) { text, _ in
                store.updateText(item, to: text)
            }
            .presentationDetents([.medium, .large])
        case .detail(let item):
            ClipDetailView(item: item) { copy(item) }
                .presentationDetents([.medium, .large])
        }
    }

    // MARK: 分類標籤列

    private var chipBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                chip(title: "全部", emoji: "✨", count: scoped.count,
                     tint: Color.green, selected: activeCategory == nil) {
                    selectedCategory = nil
                }
                ForEach(categories, id: \.name) { entry in
                    chip(title: entry.name, emoji: ClipCategory.emoji(entry.name), count: entry.count,
                         tint: Color(uiColor: ClipCategory.color(entry.name)),
                         selected: activeCategory == entry.name) {
                        selectedCategory = entry.name
                    }
                    .contextMenu { categoryMenu(entry.name) }
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
        }
    }

    private func chip(title: String, emoji: String, count: Int, tint: Color,
                      selected: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 4) {
                Text(emoji)
                Text(title).bold()
                Text("\(count)")
                    .foregroundStyle(selected ? Color.white.opacity(0.85) : Color.secondary)
            }
            .font(.footnote)
            .foregroundStyle(selected ? Color.white : Color.primary)
            .padding(.horizontal, 12)
            .padding(.vertical, 7)
            .background(
                Capsule().fill(selected ? tint : Color(uiColor: .secondarySystemGroupedBackground))
            )
        }
        .buttonStyle(.plain)
    }

    @ViewBuilder
    private func categoryMenu(_ name: String) -> some View {
        if !ClipCategory.defaultNames.contains(name) {
            Button {
                renamingCategory = name
                renameText = name
                showRenameCategory = true
            } label: {
                Label("重新命名", systemImage: "pencil")
            }
            Button(role: .destructive) {
                store.deleteCategory(name)
            } label: {
                Label("刪除分類", systemImage: "trash")
            }
        }
    }

    // MARK: 清單

    private var itemList: some View {
        List {
            if sortMode == 1 {
                ForEach(frequentItems) { item in
                    itemRow(item)
                }
            } else {
                ForEach(groups, id: \.day) { group in
                    Section {
                        ForEach(group.items) { item in
                            itemRow(item)
                        }
                    } header: {
                        Text(group.day, format: .dateTime.year().month().day())
                    }
                }
            }
        }
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
        .overlay { emptyState }
        .safeAreaInset(edge: .bottom) {
            if selecting {
                selectionBar
            } else {
                Color.clear.frame(height: 60)
            }
        }
    }

    private var sortMenu: some View {
        Menu {
            Picker("排序", selection: $sortMode) {
                Text("最新優先").tag(0)
                Text("常用優先").tag(1)
            }
        } label: {
            Image(systemName: "arrow.up.arrow.down.circle")
        }
    }

    private var selectionBar: some View {
        HStack(spacing: 18) {
            Button(selectedIDs.count == filtered.count ? "取消全選" : "全選") {
                if selectedIDs.count == filtered.count {
                    selectedIDs = []
                } else {
                    selectedIDs = Set(filtered.map { $0.id })
                }
            }
            Spacer()
            Group {
                Button {
                    store.setPinned(ids: selectedIDs, pinned: true)
                    endSelecting()
                } label: {
                    Label("釘選", systemImage: "pin")
                }
                Menu {
                    ForEach(categoryChoices, id: \.self) { name in
                        Button(ClipCategory.emoji(name) + " " + name) {
                            store.setCategory(ids: selectedIDs, to: name)
                            endSelecting()
                        }
                    }
                } label: {
                    Label("分類", systemImage: "folder")
                }
                Button(role: .destructive) {
                    store.delete(ids: selectedIDs)
                    endSelecting()
                } label: {
                    Label("刪除", systemImage: "trash")
                }
            }
            .disabled(selectedIDs.isEmpty)
        }
        .font(.subheadline)
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(.regularMaterial)
    }

    private func endSelecting() {
        selecting = false
        selectedIDs = []
    }

    private func tap(_ item: ClipItem) {
        if selecting {
            if selectedIDs.contains(item.id) {
                selectedIDs.remove(item.id)
            } else {
                selectedIDs.insert(item.id)
            }
        } else {
            copy(item)
        }
    }

    @ViewBuilder
    private var emptyState: some View {
        if filtered.isEmpty {
            VStack(spacing: 10) {
                Image(systemName: pinnedOnly ? "pin.slash" : "doc.on.clipboard")
                    .font(.system(size: 44))
                    .foregroundStyle(.tertiary)
                Text(pinnedOnly ? "左滑項目即可釘選" : "還沒有內容，去複製些東西吧")
                    .foregroundStyle(.secondary)
            }
        }
    }

    private func itemRow(_ item: ClipItem) -> some View {
        Button { tap(item) } label: { rowCard(item) }
            .buttonStyle(.plain)
            .listRowSeparator(.hidden)
            .listRowBackground(Color.clear)
            .listRowInsets(EdgeInsets(top: 4, leading: 16, bottom: 4, trailing: 16))
            .swipeActions(edge: .trailing) {
                Button(role: .destructive) {
                    store.delete(item)
                } label: {
                    Label("刪除", systemImage: "trash")
                }
            }
            .swipeActions(edge: .leading) {
                Button {
                    store.togglePin(item)
                } label: {
                    Label(item.pinned ? "取消釘選" : "釘選", systemImage: "pin")
                }
                .tint(.orange)
            }
            .contextMenu { menuItems(item) }
    }

    private func rowCard(_ item: ClipItem) -> some View {
        let name = item.categoryName
        let tint = Color(uiColor: ClipCategory.color(name))
        return HStack(alignment: .top, spacing: 12) {
            if selecting {
                Image(systemName: selectedIDs.contains(item.id) ? "checkmark.circle.fill" : "circle")
                    .font(.title3)
                    .foregroundStyle(selectedIDs.contains(item.id) ? Color.green : Color.secondary)
                    .frame(height: 40)
            }
            Text(ClipCategory.emoji(name))
                .font(.title3)
                .frame(width: 40, height: 40)
                .background(tint.opacity(0.15), in: RoundedRectangle(cornerRadius: 12, style: .continuous))

            VStack(alignment: .leading, spacing: 6) {
                Text(item.displayText)
                    .font(.body)
                    .lineLimit(3)
                    .multilineTextAlignment(.leading)

                HStack(spacing: 6) {
                    Text(name)
                        .font(.caption2.bold())
                        .foregroundStyle(tint)
                        .padding(.horizontal, 7)
                        .padding(.vertical, 2)
                        .background(tint.opacity(0.12), in: Capsule())
                    Text(item.date, style: .time)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    if item.pinned {
                        Image(systemName: "pin.fill")
                            .font(.caption)
                            .foregroundStyle(.orange)
                    }
                    if item.isSensitive {
                        Image(systemName: "eye.slash")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    if item.uses > 0 {
                        Text("×\(item.uses)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
            }
            Spacer(minLength: 0)
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            Color(uiColor: .secondarySystemGroupedBackground),
            in: RoundedRectangle(cornerRadius: 16, style: .continuous)
        )
        .contentShape(Rectangle())
    }

    // MARK: 長按選單

    @ViewBuilder
    private func menuItems(_ item: ClipItem) -> some View {
        Button { copy(item) } label: {
            Label("複製", systemImage: "doc.on.doc")
        }
        Button { store.togglePin(item) } label: {
            Label(item.pinned ? "取消釘選" : "釘選", systemImage: item.pinned ? "pin.slash" : "pin")
        }

        if let link = item.linkURL {
            Button { openURL(link) } label: {
                Label("開啟連結", systemImage: "safari")
            }
        }
        if let coord = item.coordinate {
            Button { openMap(coord) } label: {
                Label("在地圖開啟", systemImage: "map")
            }
            Menu {
                ForEach(ClipCoordinate.formats(lat: coord.lat, lon: coord.lon), id: \.title) { format in
                    Button(format.title + "：" + format.text) {
                        copyText(format.text, record: true)
                    }
                }
            } label: {
                Label("複製成其他格式", systemImage: "arrow.triangle.2.circlepath")
            }
        }

        Group {
            Button { activeSheet = .detail(item) } label: {
                Label("查看全文", systemImage: "text.alignleft")
            }
            Button { activeSheet = .edit(item) } label: {
                Label("編輯內容", systemImage: "pencil")
            }
            Button { store.toggleSensitive(item) } label: {
                Label(item.isSensitive ? "取消敏感標記" : "標記為敏感", systemImage: item.isSensitive ? "eye" : "eye.slash")
            }
        }

        ShareLink(item: item.text) {
            Label("分享", systemImage: "square.and.arrow.up")
        }

        Menu {
            ForEach(categoryChoices, id: \.self) { name in
                Button(ClipCategory.emoji(name) + " " + name) {
                    store.setCategory(item, to: name)
                }
            }
            Button("新增分類…") {
                itemForNewCategory = item
                newCategoryName = ""
                showNewCategory = true
            }
            if item.category != nil {
                Button("恢復自動分類") {
                    store.setCategory(item, to: nil)
                }
            }
        } label: {
            Label("移到分類", systemImage: "folder")
        }

        Button(role: .destructive) { store.delete(item) } label: {
            Label("刪除", systemImage: "trash")
        }
    }

    // MARK: 動作

    @ViewBuilder
    private var toast: some View {
        if showToast {
            Text("已複製")
                .font(.subheadline.bold())
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
                .background(.ultraThinMaterial, in: Capsule())
                .padding(.top, 8)
                .transition(.opacity)
        }
    }

    private func applyNewCategory() {
        if let item = itemForNewCategory {
            store.setCategory(item, to: newCategoryName)
        }
        itemForNewCategory = nil
    }

    private func openMap(_ coord: (lat: Double, lon: Double)) {
        if let url = URL(string: "http://maps.apple.com/?ll=\(coord.lat),\(coord.lon)") {
            openURL(url)
        }
    }

    private func applyRenameCategory() {
        if let old = renamingCategory {
            let name = renameText.trimmingCharacters(in: .whitespacesAndNewlines)
            store.renameCategory(old, to: name)
            if !name.isEmpty && selectedCategory == old {
                selectedCategory = name
            }
        }
        renamingCategory = nil
    }

    private func copy(_ item: ClipItem) {
        store.bumpUse(item)
        copyText(ClipTemplate.expand(item.text), record: false)
    }

    private func copyText(_ text: String, record: Bool) {
        ClipboardMonitor.shared.copy(text)
        if record { store.add(text) }
        UINotificationFeedbackGenerator().notificationOccurred(.success)
        withAnimation { showToast = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            withAnimation { showToast = false }
        }
    }
}

// MARK: - 文字編輯 / 全文檢視

struct TextEditorSheet: View {
    let title: String
    let initialText: String
    let categoryChoices: [String]          // 空陣列 = 不顯示分類選擇
    let onSave: (String, String?) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var text = ""
    @State private var category = ""       // 空字串 = 自動分類

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                TextEditor(text: $text)
                    .scrollContentBackground(.hidden)
                    .padding(8)
                    .frame(minHeight: 160)
                    .background(
                        Color(uiColor: .secondarySystemGroupedBackground),
                        in: RoundedRectangle(cornerRadius: 12, style: .continuous)
                    )

                Text("可用 {日期}、{時間}、{日期時間}，貼上時會自動換成現在的日期時間。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)

                if !categoryChoices.isEmpty {
                    Picker("分類", selection: $category) {
                        Text("自動").tag("")
                        ForEach(categoryChoices, id: \.self) { name in
                            Text(ClipCategory.emoji(name) + " " + name).tag(name)
                        }
                    }
                    .pickerStyle(.menu)
                }
                Spacer(minLength: 0)
            }
            .padding(16)
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("儲存") {
                        onSave(text, category.isEmpty ? nil : category)
                        dismiss()
                    }
                    .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            .onAppear { text = initialText }
        }
    }
}

struct ClipDetailView: View {
    let item: ClipItem
    let onCopy: () -> Void

    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    HStack(spacing: 8) {
                        Text(ClipCategory.emoji(item.categoryName) + " " + item.categoryName)
                            .font(.caption.bold())
                        Text(item.date, format: .dateTime.year().month().day().hour().minute())
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    Text(item.text)
                        .font(.body)
                        .textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .leading)

                    Text("共 \(item.text.count) 字")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(16)
            }
            .navigationTitle("內容")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("關閉") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("複製") { onCopy() }
                }
            }
        }
    }
}

// MARK: - 設定

struct SettingsView: View {
    @ObservedObject private var store = ClipStore.shared
    @ObservedObject private var pip = PiPManager.shared
    @AppStorage("recordingPaused") private var paused = false
    @AppStorage("retentionDays") private var retentionDays = 0
    @AppStorage("lockEnabled") private var lockEnabled = false
    @AppStorage("sensitiveMode") private var sensitiveMode = 2
    @AppStorage("ignoreKeywords") private var ignoreKeywords = ""
    @AppStorage("syncLimit") private var syncLimit = 30
    @AppStorage("pollInterval") private var pollInterval = 0.5

    @State private var showClearConfirm = false
    @State private var shareItem: ShareItem? = nil
    @State private var showImporter = false
    @State private var backupMessage: String? = nil

    private var exportText: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm"
        return store.items.map { item in
            "[" + item.categoryName + "] " + formatter.string(from: item.date) + "\n" + item.displayText
        }.joined(separator: "\n\n")
    }

    private var unpinnedCount: Int {
        store.items.filter { !$0.pinned }.count
    }

    private var groupText: String {
        ClipFile.groupAvailable ? "可用" : "不可用（簽名工具沒保留）"
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Toggle("背景剪貼簿（懸浮視窗）", isOn: Binding(
                        get: { pip.isActive || pip.isStarting },
                        set: { $0 ? pip.start() : pip.stop() }
                    ))
                } header: {
                    Text("背景擷取")
                } footer: {
                    Text("開啟後會出現一個小視窗，切到其他 App 也會繼續記錄你複製的內容。")
                }

                Section {
                    Button {
                        if let url = URL(string: UIApplication.openSettingsURLString) {
                            UIApplication.shared.open(url)
                        }
                    } label: {
                        Label("開啟 iOS 設定", systemImage: "hand.raised")
                    }
                } header: {
                    Text("貼上權限")
                } footer: {
                    Text("到「剪貼清單 > 從其他 App 貼上」選「允許」，否則每次複製都會跳出貼上提示。")
                }

                Section {
                    Text("到 iOS 設定 > 一般 > 鍵盤 > 鍵盤 > 新增鍵盤，選「剪貼清單」，再開啟「允許完整取用」。輸入時按地球鍵切換；點一下卡片就貼上。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                } header: {
                    Text("鍵盤使用說明")
                }

                Section {
                    Text("App Group：" + groupText)
                    HStack {
                        Text("上次同步到鍵盤")
                        Spacer()
                        if let last = store.lastPublish {
                            Text(last, style: .relative)
                                .foregroundStyle(.secondary)
                        } else {
                            Text("尚未同步")
                                .foregroundStyle(.secondary)
                        }
                    }
                    Text("已記錄：\(store.items.count) 筆")
                } header: {
                    Text("鍵盤共用狀態")
                } footer: {
                    Text("App Group 不可用時，鍵盤會改走備援，並在你切到鍵盤時自己記錄剪貼簿。")
                }

                Section {
                    Picker("疑似敏感內容", selection: $sensitiveMode) {
                        Text("不處理").tag(0)
                        Text("不記錄").tag(1)
                        Text("遮住並不同步").tag(2)
                    }
                    TextField("自訂關鍵字（用逗號分隔）", text: $ignoreKeywords)
                    Picker("備援同步筆數", selection: $syncLimit) {
                        Text("關閉").tag(0)
                        Text("最近 10 筆").tag(10)
                        Text("最近 30 筆").tag(30)
                        Text("最近 100 筆").tag(100)
                    }
                } header: {
                    Text("隱私")
                } footer: {
                    Text("敏感內容＝6 位數驗證碼、疑似密碼，以及含有你關鍵字的內容。「遮住並不同步」會把它顯示成圓點，也不放進備援通道。備援通道只在沒有 App Group 時使用，iOS 沒辦法限制其他 App 讀取它，所以建議只同步少量。")
                }

                Section {
                    Toggle("暫停記錄", isOn: $paused)
                    Picker("檢查頻率", selection: $pollInterval) {
                        Text("0.5 秒（即時）").tag(0.5)
                        Text("1 秒").tag(1.0)
                        Text("2 秒（較省電）").tag(2.0)
                    }
                    Picker("自動刪除舊項目", selection: $retentionDays) {
                        Text("不自動刪除").tag(0)
                        Text("7 天前的").tag(7)
                        Text("30 天前的").tag(30)
                        Text("90 天前的").tag(90)
                        Text("1 年前的").tag(365)
                    }
                } header: {
                    Text("記錄")
                } footer: {
                    Text("暫停時複製的內容不會被記錄。釘選的項目（包含手動新增的片語）不會被自動刪除。檢查頻率越低越省電，但鍵盤的釘選／刪除也會慢一點生效。")
                }

                Section {
                    Toggle("使用 Face ID／密碼鎖定", isOn: $lockEnabled)
                } header: {
                    Text("安全")
                } footer: {
                    Text("離開 App 再回來時需要驗證，背景記錄不受影響。注意：鍵盤無法上鎖，內容仍可在鍵盤中看到。")
                }

                Section {
                    Button {
                        exportBackup()
                    } label: {
                        Label("匯出備份（JSON）", systemImage: "square.and.arrow.up.on.square")
                    }
                    Button {
                        showImporter = true
                    } label: {
                        Label("匯入備份", systemImage: "square.and.arrow.down")
                    }
                } header: {
                    Text("備份")
                } footer: {
                    Text("重新安裝 App（或換簽名／Bundle ID）後，iOS 會刪除 App 內的資料，所以重裝前請先匯出備份。")
                }

                Section {
                    Stepper("最多保留 \(store.maxItems) 筆", value: $store.maxItems, in: 20...1000, step: 20)
                    ShareLink(item: exportText) {
                        Label("匯出全部（文字）", systemImage: "square.and.arrow.up")
                    }
                    Button("清除全部（保留釘選）", role: .destructive) {
                        showClearConfirm = true
                    }
                } header: {
                    Text("儲存")
                }
            }
            .navigationTitle("設定")
            .onChange(of: retentionDays) { _ in
                store.applyRetention()
            }
            .onChange(of: pollInterval) { _ in
                ClipboardMonitor.shared.restartTimer()
            }
            .onChange(of: syncLimit) { _ in
                store.republish()
            }
            .confirmationDialog("確定要清除全部嗎？", isPresented: $showClearConfirm, titleVisibility: .visible) {
                Button("清除 \(unpinnedCount) 筆", role: .destructive) {
                    store.clearUnpinned()
                }
                Button("取消", role: .cancel) {}
            } message: {
                Text("釘選的項目會保留。刪除後 6 秒內可以在畫面下方按「復原」。")
            }
            .sheet(item: $shareItem) { item in
                ActivityView(items: [item.url])
            }
            .fileImporter(isPresented: $showImporter, allowedContentTypes: [.json]) { result in
                handleImport(result)
            }
            .alert("備份", isPresented: Binding(
                get: { backupMessage != nil },
                set: { if !$0 { backupMessage = nil } }
            )) {
                Button("好", role: .cancel) {}
            } message: {
                Text(backupMessage ?? "")
            }
        }
    }

    private func exportBackup() {
        guard let data = store.backupData() else {
            backupMessage = "匯出失敗"
            return
        }
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyyMMdd-HHmm"
        let name = "ClipList-backup-" + formatter.string(from: Date()) + ".json"
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(name)
        do {
            try data.write(to: url, options: .atomic)
            shareItem = ShareItem(url: url)
        } catch {
            backupMessage = "匯出失敗：" + error.localizedDescription
        }
    }

    private func handleImport(_ result: Result<URL, Error>) {
        switch result {
        case .success(let url):
            let accessing = url.startAccessingSecurityScopedResource()
            defer {
                if accessing { url.stopAccessingSecurityScopedResource() }
            }
            guard let data = try? Data(contentsOf: url),
                  let list = try? JSONDecoder().decode([ClipItem].self, from: data) else {
                backupMessage = "讀取失敗：檔案格式不正確"
                return
            }
            let added = store.importItems(list)
            backupMessage = "匯入完成，新增 \(added) 筆"
        case .failure(let error):
            backupMessage = "匯入失敗：" + error.localizedDescription
        }
    }
}

struct ShareItem: Identifiable {
    let id = UUID()
    let url: URL
}

struct ActivityView: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

// MARK: - 懸浮視窗影像層的容器

struct PiPHostView: UIViewRepresentable {
    func makeUIView(context: Context) -> PiPContainerView {
        PiPContainerView()
    }

    func updateUIView(_ uiView: PiPContainerView, context: Context) {}
}

final class PiPContainerView: UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        isUserInteractionEnabled = false
        layer.addSublayer(PiPManager.shared.displayLayer)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        PiPManager.shared.displayLayer.frame = bounds
    }
}

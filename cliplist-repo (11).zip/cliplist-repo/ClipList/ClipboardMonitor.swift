import UIKit

/// 輪詢剪貼簿的 changeCount，有變動才讀內容（只看 changeCount 不會觸發貼上提示）
final class ClipboardMonitor {
    static let shared = ClipboardMonitor()

    private var timer: Timer?
    /// 上次處理過的剪貼簿變動次數（跨啟動記住，避免重開 App 時把剛刪掉的內容又記回來）
    private var lastChangeCount: Int = (UserDefaults.standard.object(forKey: "lastClipboardChange") as? Int) ?? -1

    private init() {}

    func start() {
        guard timer == nil else { return }
        scheduleTimer()
        check()
    }

    /// 設定頁改了檢查頻率之後呼叫
    func restartTimer() {
        guard timer != nil else { return }
        timer?.invalidate()
        timer = nil
        scheduleTimer()
    }

    private func scheduleTimer() {
        let stored = UserDefaults.standard.double(forKey: "pollInterval")
        let interval = stored > 0 ? stored : 0.5
        let t = Timer(timeInterval: interval, repeats: true) { [weak self] _ in
            self?.check()
        }
        RunLoop.main.add(t, forMode: .common)
        timer = t
    }

    func check(force: Bool = false) {
        applyKeyboardCommands()
        let pb = UIPasteboard.general
        let count = pb.changeCount
        guard force || count != lastChangeCount else { return }
        lastChangeCount = count
        UserDefaults.standard.set(count, forKey: "lastClipboardChange")
        // 暫停記錄時，期間複製的內容不記（恢復後也不會補記）
        if UserDefaults.standard.bool(forKey: "recordingPaused") { return }
        guard pb.hasStrings || pb.hasURLs else { return }
        guard let text = pb.string ?? pb.url?.absoluteString else { return }
        ClipStore.shared.add(text)
        PiPManager.shared.show(text: displayText(for: text))
    }

    /// 懸浮視窗上顯示的文字：敏感內容不要直接秀出來
    private func displayText(for text: String) -> String {
        let store = ClipStore.shared
        let byRule = store.isSensitiveText(text)
        let byMark = store.items.first(where: { $0.text == text })?.isSensitive == true
        return (byRule || byMark) ? "•••••• （敏感內容已隱藏）" : text
    }

    /// 鍵盤長按項目後送來的「釘選／刪除」指令
    private func applyKeyboardCommands() {
        for command in ClipShare.takeCommands() {
            ClipStore.shared.apply(command)
        }
    }

    /// 在 App 內點選項目複製時使用（不會被當成新的複製再記錄一次）
    func copy(_ text: String) {
        UIPasteboard.general.string = text
        lastChangeCount = UIPasteboard.general.changeCount
        UserDefaults.standard.set(lastChangeCount, forKey: "lastClipboardChange")
        PiPManager.shared.show(text: displayText(for: text))
    }
}

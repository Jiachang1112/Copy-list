import SwiftUI
import LocalAuthentication

/// 用 Face ID / Touch ID / 裝置密碼鎖住 App 畫面（背景記錄不受影響）
final class AppLock: ObservableObject {
    static let shared = AppLock()

    @Published private(set) var isLocked: Bool
    private var isAuthenticating = false

    private init() {
        isLocked = UserDefaults.standard.bool(forKey: "lockEnabled")
    }

    private var enabled: Bool {
        UserDefaults.standard.bool(forKey: "lockEnabled")
    }

    /// App 進到背景時上鎖（有開啟鎖定才會）
    func lockIfNeeded() {
        if enabled {
            isLocked = true
        }
    }

    func unlock() {
        guard isLocked, !isAuthenticating else { return }

        let context = LAContext()
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else {
            // 裝置沒有設定密碼 / Face ID：無法驗證，直接放行，避免把自己鎖在外面
            isLocked = false
            return
        }

        isAuthenticating = true
        context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "解鎖剪貼清單") { success, _ in
            DispatchQueue.main.async {
                self.isAuthenticating = false
                if success {
                    self.isLocked = false
                }
            }
        }
    }
}

struct LockScreenView: View {
    var body: some View {
        ZStack {
            Color(uiColor: .systemBackground)
                .ignoresSafeArea()

            VStack(spacing: 16) {
                Image(systemName: "lock.fill")
                    .font(.system(size: 48))
                    .foregroundStyle(.secondary)
                Text("剪貼清單已鎖定")
                    .font(.headline)
                Button {
                    AppLock.shared.unlock()
                } label: {
                    Label("解鎖", systemImage: "faceid")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 24)
                        .padding(.vertical, 12)
                        .background(Capsule().fill(Color.green))
                }
            }
        }
    }
}

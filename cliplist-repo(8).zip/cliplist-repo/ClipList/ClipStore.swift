import Foundation
import Combine

final class ClipStore: ObservableObject {
    static let shared = ClipStore()

    @Published private(set) var items: [ClipItem] = []
    @Published var maxItems: Int {
        didSet {
            UserDefaults.standard.set(maxItems, forKey: "maxItems")
            trim()
            save()
        }
    }

    private let fileURL: URL

    private init() {
        fileURL = ClipFile.url
        let saved = UserDefaults.standard.integer(forKey: "maxItems")
        maxItems = saved == 0 ? 200 : saved
        load()
        trim()
        if let data = try? JSONEncoder().encode(items) {
            ClipShare.publish(data)
        }
    }

    func add(_ text: String) {
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        if let index = items.firstIndex(where: { $0.text == text }) {
            var item = items.remove(at: index)
            item.date = Date()
            items.insert(item, at: 0)
        } else {
            items.insert(ClipItem(text: text), at: 0)
        }
        trim()
        save()
    }

    func delete(_ item: ClipItem) {
        items.removeAll { $0.id == item.id }
        save()
    }

    func togglePin(_ item: ClipItem) {
        guard let index = items.firstIndex(where: { $0.id == item.id }) else { return }
        items[index].pinned.toggle()
        save()
    }

    /// 指定分類；name 為空（或 nil）代表恢復成自動分類
    func setCategory(_ item: ClipItem, to name: String?) {
        guard let index = items.firstIndex(where: { $0.id == item.id }) else { return }
        let trimmed = (name ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        items[index].category = trimmed.isEmpty ? nil : trimmed
        save()
    }

    /// 手動新增的片語：預設釘選，不會被自動清掉
    func addManual(_ text: String, category: String?) {
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        items.removeAll { $0.text == text }
        var item = ClipItem(text: text)
        item.pinned = true
        let name = (category ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        item.category = name.isEmpty ? nil : name
        items.insert(item, at: 0)
        save()
    }

    /// 編輯內容；如果改完和別筆一樣，就合併成一筆
    func updateText(_ item: ClipItem, to newText: String) {
        guard !newText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              let index = items.firstIndex(where: { $0.id == item.id }) else { return }
        items[index].text = newText
        items.removeAll { $0.id != item.id && $0.text == newText }
        save()
    }

    /// 重新命名自訂分類
    func renameCategory(_ old: String, to new: String) {
        let name = new.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty else { return }
        for index in items.indices where items[index].category == old {
            items[index].category = name
        }
        save()
    }

    /// 刪除自訂分類：裡面的項目回到自動分類
    func deleteCategory(_ name: String) {
        for index in items.indices where items[index].category == name {
            items[index].category = nil
        }
        save()
    }

    /// 處理從鍵盤送來的指令
    func apply(_ command: ClipCommand) {
        guard let index = items.firstIndex(where: { $0.id == command.id }) else { return }
        switch command.action {
        case "pin":
            items[index].pinned = true
        case "unpin":
            items[index].pinned = false
        case "delete":
            items.remove(at: index)
        default:
            return
        }
        save()
    }

    /// 依「自動刪除」設定清掉舊項目
    func applyRetention() {
        trim()
        save()
    }

    func clearUnpinned() {
        items = items.filter { $0.pinned }
        save()
    }

    private func trim() {
        let days = UserDefaults.standard.integer(forKey: "retentionDays")
        var cutoff: Date? = nil
        if days > 0 {
            cutoff = Calendar.current.date(byAdding: .day, value: -days, to: Date())
        }
        var count = 0
        items = items.filter { item in
            if item.pinned { return true }
            if let cutoff = cutoff, item.date < cutoff { return false }
            count += 1
            return count <= maxItems
        }
    }

    private func load() {
        guard let data = try? Data(contentsOf: fileURL),
              let decoded = try? JSONDecoder().decode([ClipItem].self, from: data) else { return }
        items = decoded
    }

    private func save() {
        guard let data = try? JSONEncoder().encode(items) else { return }
        try? data.write(to: fileURL, options: .atomic)
        ClipShare.publish(data)
    }
}

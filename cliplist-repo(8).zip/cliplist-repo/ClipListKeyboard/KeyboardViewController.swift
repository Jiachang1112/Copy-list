import UIKit

// MARK: - 卡片

final class ClipCell: UICollectionViewCell {
    static let reuseID = "ClipCell"

    private let bar = UIView()
    private let label = UILabel()
    private let emojiLabel = UILabel()

    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = .systemBackground
        contentView.layer.cornerRadius = 12
        contentView.layer.masksToBounds = true

        bar.translatesAutoresizingMaskIntoConstraints = false

        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.lineBreakMode = .byTruncatingTail
        label.font = .systemFont(ofSize: 14)
        label.textColor = .label

        emojiLabel.translatesAutoresizingMaskIntoConstraints = false
        emojiLabel.font = .systemFont(ofSize: 12)
        emojiLabel.setContentHuggingPriority(.required, for: .horizontal)
        emojiLabel.setContentCompressionResistancePriority(.required, for: .horizontal)

        contentView.addSubview(bar)
        contentView.addSubview(label)
        contentView.addSubview(emojiLabel)

        NSLayoutConstraint.activate([
            bar.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            bar.topAnchor.constraint(equalTo: contentView.topAnchor),
            bar.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            bar.widthAnchor.constraint(equalToConstant: 4),

            emojiLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 5),
            emojiLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -6),

            label.leadingAnchor.constraint(equalTo: bar.trailingAnchor, constant: 8),
            label.trailingAnchor.constraint(equalTo: emojiLabel.leadingAnchor, constant: -4),
            label.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 6),
            label.bottomAnchor.constraint(lessThanOrEqualTo: contentView.bottomAnchor, constant: -6)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func configure(with item: ClipItem) {
        let name = item.categoryName
        bar.backgroundColor = ClipCategory.color(name)
        emojiLabel.text = ClipCategory.emoji(name)
        label.text = (item.pinned ? "📌 " : "") + item.text
    }

    override var isHighlighted: Bool {
        didSet {
            contentView.backgroundColor = isHighlighted ? .systemGray4 : .systemBackground
        }
    }
}

// MARK: - 鍵盤

/// 顯示「剪貼清單」歷史的鍵盤：
/// 卡片格狀排列、點一下就貼上；可選欄數 × 列數；可依分類篩選；可用英數字搜尋。
///
/// 資料來源（有哪個用哪個，最後合併）：
/// 1. App Group 共用檔（簽名工具有保留 App Group 時）
/// 2. 具名剪貼簿備援（App 端同步出來）
/// 3. 鍵盤自己記錄：每次鍵盤出現時，把目前剪貼簿的文字存在鍵盤自己的資料夾（需要「允許完整取用」）
final class KeyboardViewController: UIInputViewController {
    private let normalHeight: CGFloat = 310
    private let searchHeight: CGFloat = 370
    private let spacing: CGFloat = 6

    private let defaults = UserDefaults.standard

    private var columns: Int {
        get {
            let value = defaults.integer(forKey: "kb_cols")
            return (1...4).contains(value) ? value : 2
        }
        set {
            defaults.set(newValue, forKey: "kb_cols")
        }
    }

    private var rows: Int {
        get {
            let value = defaults.integer(forKey: "kb_rows")
            return (1...4).contains(value) ? value : 3
        }
        set {
            defaults.set(newValue, forKey: "kb_rows")
        }
    }

    private var allItems: [ClipItem] = []
    private var visibleItems: [ClipItem] = []
    private var selectedCategory: String? = nil
    private var diagnosticText = ""
    private var lastCollectionSize = CGSize.zero

    private var query = "" {
        didSet { applyFilter() }
    }

    private var isSearching = false {
        didSet { updateMode() }
    }

    private var heightConstraint: NSLayoutConstraint!
    private var deleteTimer: Timer?
    private var actionPanel: UIView?
    private let pinnedKey = "__pinned__"

    private let rootStack = UIStackView()
    private let toolbar = UIStackView()
    private let spacer = UIView()
    private let queryLabel = UILabel()
    private let emptyLabel = UILabel()
    private let chipScroll = UIScrollView()
    private let chipStack = UIStackView()
    private let searchPad = UIStackView()
    private let bottomBar = UIStackView()

    private lazy var searchButton = makeButton(systemImage: "magnifyingglass")
    private lazy var colsButton = makeButton(title: "欄 2")
    private lazy var rowsButton = makeButton(title: "列 3")

    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumInteritemSpacing = spacing
        layout.minimumLineSpacing = spacing
        let view = UICollectionView(frame: .zero, collectionViewLayout: layout)
        view.backgroundColor = .clear
        view.alwaysBounceVertical = true
        view.contentInsetAdjustmentBehavior = .never
        view.dataSource = self
        view.delegate = self
        view.register(ClipCell.self, forCellWithReuseIdentifier: ClipCell.reuseID)
        return view
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        buildUI()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        reload()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let size = collectionView.bounds.size
        if size != lastCollectionSize {
            lastCollectionSize = size
            collectionView.collectionViewLayout.invalidateLayout()
        }
    }

    // MARK: - 畫面

    private func buildUI() {
        heightConstraint = view.heightAnchor.constraint(equalToConstant: normalHeight)
        heightConstraint.priority = UILayoutPriority(999)
        heightConstraint.isActive = true

        // 上方工具列：搜尋 / 欄 / 列
        searchButton.addTarget(self, action: #selector(tapSearchToggle), for: .touchUpInside)
        colsButton.addTarget(self, action: #selector(tapColumns), for: .touchUpInside)
        rowsButton.addTarget(self, action: #selector(tapRows), for: .touchUpInside)

        queryLabel.font = .systemFont(ofSize: 15)
        queryLabel.backgroundColor = .systemBackground
        queryLabel.layer.cornerRadius = 8
        queryLabel.layer.masksToBounds = true

        toolbar.axis = .horizontal
        toolbar.spacing = 6
        toolbar.distribution = .fill
        toolbar.addArrangedSubview(searchButton)
        toolbar.addArrangedSubview(colsButton)
        toolbar.addArrangedSubview(rowsButton)
        toolbar.addArrangedSubview(queryLabel)
        toolbar.addArrangedSubview(spacer)

        // 分類標籤列（橫向捲動）
        chipStack.translatesAutoresizingMaskIntoConstraints = false
        chipStack.axis = .horizontal
        chipStack.spacing = 6
        chipStack.alignment = .fill
        chipScroll.showsHorizontalScrollIndicator = false
        chipScroll.addSubview(chipStack)
        NSLayoutConstraint.activate([
            chipStack.leadingAnchor.constraint(equalTo: chipScroll.contentLayoutGuide.leadingAnchor),
            chipStack.trailingAnchor.constraint(equalTo: chipScroll.contentLayoutGuide.trailingAnchor),
            chipStack.topAnchor.constraint(equalTo: chipScroll.contentLayoutGuide.topAnchor),
            chipStack.bottomAnchor.constraint(equalTo: chipScroll.contentLayoutGuide.bottomAnchor),
            chipStack.heightAnchor.constraint(equalTo: chipScroll.frameLayoutGuide.heightAnchor)
        ])

        // 空狀態
        emptyLabel.translatesAutoresizingMaskIntoConstraints = false
        emptyLabel.numberOfLines = 0
        emptyLabel.textAlignment = .center
        emptyLabel.textColor = .secondaryLabel
        emptyLabel.font = .systemFont(ofSize: 14)

        // 搜尋用的迷你鍵盤
        buildSearchPad()

        // 下方：地球 / 空白 / 刪除 / 換行
        let globeButton = makeButton(systemImage: "globe")
        globeButton.addTarget(self, action: #selector(handleInputModeList(from:with:)), for: .allTouchEvents)
        let leftButton = makeButton(systemImage: "chevron.left")
        leftButton.addTarget(self, action: #selector(tapCursorLeft), for: .touchUpInside)
        let rightButton = makeButton(systemImage: "chevron.right")
        rightButton.addTarget(self, action: #selector(tapCursorRight), for: .touchUpInside)
        let spaceButton = makeButton(title: "空白")
        spaceButton.addTarget(self, action: #selector(tapSpace), for: .touchUpInside)
        let deleteButton = makeButton(systemImage: "delete.left")
        deleteButton.addTarget(self, action: #selector(tapDelete), for: .touchUpInside)
        let holdGesture = UILongPressGestureRecognizer(target: self, action: #selector(holdDelete(_:)))
        holdGesture.minimumPressDuration = 0.4
        deleteButton.addGestureRecognizer(holdGesture)
        let returnButton = makeButton(systemImage: "return")
        returnButton.addTarget(self, action: #selector(tapReturn), for: .touchUpInside)

        bottomBar.axis = .horizontal
        bottomBar.spacing = 6
        bottomBar.distribution = .fill
        bottomBar.addArrangedSubview(globeButton)
        bottomBar.addArrangedSubview(leftButton)
        bottomBar.addArrangedSubview(rightButton)
        bottomBar.addArrangedSubview(spaceButton)
        bottomBar.addArrangedSubview(deleteButton)
        bottomBar.addArrangedSubview(returnButton)

        // 整體由上到下排列
        rootStack.translatesAutoresizingMaskIntoConstraints = false
        rootStack.axis = .vertical
        rootStack.spacing = 4
        rootStack.distribution = .fill
        rootStack.addArrangedSubview(toolbar)
        rootStack.addArrangedSubview(chipScroll)
        rootStack.addArrangedSubview(collectionView)
        rootStack.addArrangedSubview(searchPad)
        rootStack.addArrangedSubview(bottomBar)

        view.addSubview(rootStack)
        view.addSubview(emptyLabel)

        let cardPress = UILongPressGestureRecognizer(target: self, action: #selector(handleCardLongPress(_:)))
        cardPress.minimumPressDuration = 0.45
        collectionView.addGestureRecognizer(cardPress)

        collectionView.setContentHuggingPriority(.defaultLow, for: .vertical)
        collectionView.setContentCompressionResistancePriority(.defaultLow, for: .vertical)
        spacer.setContentHuggingPriority(.defaultLow, for: .horizontal)
        queryLabel.setContentHuggingPriority(.defaultLow, for: .horizontal)

        NSLayoutConstraint.activate([
            rootStack.topAnchor.constraint(equalTo: view.topAnchor, constant: 4),
            rootStack.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -4),
            rootStack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 6),
            rootStack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -6),

            toolbar.heightAnchor.constraint(equalToConstant: 32),
            searchButton.widthAnchor.constraint(equalToConstant: 44),
            colsButton.widthAnchor.constraint(equalToConstant: 64),
            rowsButton.widthAnchor.constraint(equalToConstant: 64),

            chipScroll.heightAnchor.constraint(equalToConstant: 28),
            searchPad.heightAnchor.constraint(equalToConstant: 186),

            bottomBar.heightAnchor.constraint(equalToConstant: 42),
            globeButton.widthAnchor.constraint(equalToConstant: 46),
            leftButton.widthAnchor.constraint(equalToConstant: 40),
            rightButton.widthAnchor.constraint(equalToConstant: 40),
            deleteButton.widthAnchor.constraint(equalToConstant: 52),
            returnButton.widthAnchor.constraint(equalToConstant: 52),

            emptyLabel.centerYAnchor.constraint(equalTo: collectionView.centerYAnchor),
            emptyLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            emptyLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24)
        ])

        refreshLayoutButtons()
        updateMode()
    }

    private func buildSearchPad() {
        searchPad.axis = .vertical
        searchPad.spacing = 4
        searchPad.distribution = .fillEqually

        let letterRows = ["1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm"]
        for (index, letters) in letterRows.enumerated() {
            let rowStack = makeRowStack()
            for letter in letters {
                rowStack.addArrangedSubview(makeKey(title: String(letter)))
            }
            if index == letterRows.count - 1 {
                let deleteKey = makeKey(systemImage: "delete.left", special: true)
                deleteKey.addTarget(self, action: #selector(tapKeyDelete), for: .touchUpInside)
                rowStack.addArrangedSubview(deleteKey)
            }
            searchPad.addArrangedSubview(rowStack)
        }

        let symbolRow = makeRowStack()
        for symbol in [".", ",", "-", "_", ":", "/", "@"] {
            symbolRow.addArrangedSubview(makeKey(title: symbol))
        }
        symbolRow.addArrangedSubview(makeKey(title: "空白", special: true))
        searchPad.addArrangedSubview(symbolRow)
    }

    private func makeRowStack() -> UIStackView {
        let stack = UIStackView()
        stack.axis = .horizontal
        stack.spacing = 4
        stack.distribution = .fillEqually
        return stack
    }

    private func makeKey(title: String? = nil, systemImage: String? = nil, special: Bool = false) -> UIButton {
        let key = makeButton(title: title, systemImage: systemImage)
        key.titleLabel?.font = .systemFont(ofSize: 17)
        key.backgroundColor = special ? .systemGray3 : .systemBackground
        if title != nil {
            key.addTarget(self, action: #selector(tapKey(_:)), for: .touchUpInside)
        }
        return key
    }

    private func makeButton(title: String? = nil, systemImage: String? = nil) -> UIButton {
        let button = UIButton(type: .system)
        if let title = title {
            button.setTitle(title, for: .normal)
        }
        if let name = systemImage {
            button.setImage(UIImage(systemName: name), for: .normal)
        }
        button.tintColor = .label
        button.backgroundColor = .systemGray4
        button.layer.cornerRadius = 8
        return button
    }

    /// 切換「一般 / 搜尋」兩種畫面
    private func updateMode() {
        searchPad.isHidden = !isSearching
        bottomBar.isHidden = isSearching
        chipScroll.isHidden = isSearching
        queryLabel.isHidden = !isSearching
        spacer.isHidden = isSearching
        colsButton.isHidden = isSearching
        rowsButton.isHidden = isSearching
        heightConstraint.constant = isSearching ? searchHeight : normalHeight
        let icon = isSearching ? "xmark" : "magnifyingglass"
        searchButton.setImage(UIImage(systemName: icon), for: .normal)
        query = ""
        applyFilter()
    }

    private func refreshLayoutButtons() {
        colsButton.setTitle("欄 \(columns)", for: .normal)
        rowsButton.setTitle("列 \(rows)", for: .normal)
        collectionView.collectionViewLayout.invalidateLayout()
    }

    // MARK: - 分類標籤

    private func rebuildChips() {
        for chip in chipStack.arrangedSubviews {
            chipStack.removeArrangedSubview(chip)
            chip.removeFromSuperview()
        }

        let summary = ClipCategory.summary(of: allItems)
        let pinnedCount = allItems.filter { $0.pinned }.count
        if let selected = selectedCategory {
            let exists = (selected == pinnedKey) ? (pinnedCount > 0) : summary.contains(where: { $0.name == selected })
            if !exists { selectedCategory = nil }
        }

        chipStack.addArrangedSubview(makeChip(title: "✨ 全部 \(allItems.count)", name: nil, tint: .systemGreen))
        if pinnedCount > 0 {
            chipStack.addArrangedSubview(makeChip(title: "📌 釘選 \(pinnedCount)", name: pinnedKey, tint: .systemOrange))
        }
        for entry in summary {
            let title = ClipCategory.emoji(entry.name) + " " + entry.name + " \(entry.count)"
            chipStack.addArrangedSubview(makeChip(title: title, name: entry.name, tint: ClipCategory.color(entry.name)))
        }
    }

    private func makeChip(title: String, name: String?, tint: UIColor) -> UIButton {
        let selected = (selectedCategory == name)
        let chip = UIButton(type: .custom)
        chip.setTitle(title, for: .normal)
        chip.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        chip.setTitleColor(selected ? .white : .label, for: .normal)
        chip.backgroundColor = selected ? tint : .systemBackground
        chip.layer.cornerRadius = 14
        chip.contentEdgeInsets = UIEdgeInsets(top: 4, left: 10, bottom: 4, right: 10)
        chip.addAction(UIAction { [weak self] _ in
            self?.selectCategory(name)
        }, for: .touchUpInside)
        return chip
    }

    private func selectCategory(_ name: String?) {
        selectedCategory = name
        rebuildChips()
        applyFilter()
    }

    // MARK: - 資料

    private func reload() {
        captureGeneralPasteboard()

        let fileItems = ClipFile.loadFile()
        let pasteboardItems = ClipShare.loadFromPasteboard()
        let own = loadOwn()

        var merged = fileItems.isEmpty ? pasteboardItems : fileItems
        for item in own where !merged.contains(where: { $0.text == item.text }) {
            merged.append(item)
        }

        // 釘選的排前面，其餘照時間（最新在前）
        allItems = sortItems(merged)

        let access = hasFullAccess ? "開" : "關"
        let group = ClipFile.groupAvailable ? "有" : "無"
        diagnosticText = "診斷：完整取用\(access)｜App Group\(group)｜共用檔\(fileItems.count)｜備援\(pasteboardItems.count)｜本機\(own.count)"

        rebuildChips()
        applyFilter()
    }

    private func sortItems(_ list: [ClipItem]) -> [ClipItem] {
        list.sorted { a, b in
            if a.pinned != b.pinned { return a.pinned }
            return a.date > b.date
        }
    }

    private func applyFilter() {
        let keyword = query.trimmingCharacters(in: .whitespaces)
        let category: String? = isSearching ? nil : selectedCategory

        visibleItems = allItems.filter { item in
            if let category = category {
                if category == pinnedKey {
                    if !item.pinned { return false }
                } else if item.categoryName != category {
                    return false
                }
            }
            if !keyword.isEmpty && !item.text.localizedCaseInsensitiveContains(keyword) { return false }
            return true
        }

        queryLabel.text = "  " + (query.isEmpty ? "輸入英數字搜尋…" : query)
        queryLabel.textColor = query.isEmpty ? .tertiaryLabel : .label

        if allItems.isEmpty {
            emptyLabel.text = "還沒有內容。\n先在任何 App 複製文字，再切到這個鍵盤就會記錄。\n（需要開啟「允許完整取用」）\n\n" + diagnosticText
        } else {
            emptyLabel.text = "找不到符合的項目"
        }
        emptyLabel.isHidden = !visibleItems.isEmpty
        collectionView.reloadData()
    }

    // MARK: - 鍵盤自己記錄剪貼簿

    private var ownFileURL: URL {
        let fm = FileManager.default
        let dir = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent("keyboard_clips.json")
    }

    private func loadOwn() -> [ClipItem] {
        guard let data = try? Data(contentsOf: ownFileURL),
              let decoded = try? JSONDecoder().decode([ClipItem].self, from: data) else { return [] }
        return decoded
    }

    private func saveOwn(_ list: [ClipItem]) {
        guard let data = try? JSONEncoder().encode(list) else { return }
        try? data.write(to: ownFileURL, options: .atomic)
    }

    private func captureGeneralPasteboard() {
        guard hasFullAccess else { return }
        let pb = UIPasteboard.general
        guard pb.hasStrings, let text = pb.string,
              !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }

        var own = loadOwn()
        if let index = own.firstIndex(where: { $0.text == text }) {
            var item = own.remove(at: index)
            item.date = Date()
            own.insert(item, at: 0)
        } else {
            own.insert(ClipItem(text: text), at: 0)
        }
        saveOwn(Array(own.prefix(100)))
    }

    // MARK: - 按鈕

    @objc private func tapSearchToggle() {
        isSearching.toggle()
    }

    @objc private func tapColumns() {
        columns = columns % 4 + 1
        refreshLayoutButtons()
    }

    @objc private func tapRows() {
        rows = rows % 4 + 1
        refreshLayoutButtons()
    }

    @objc private func tapKey(_ sender: UIButton) {
        guard let key = sender.title(for: .normal) else { return }
        query += (key == "空白") ? " " : key
    }

    @objc private func tapKeyDelete() {
        if !query.isEmpty {
            query.removeLast()
        }
    }

    // MARK: - 長按卡片的動作面板

    @objc private func handleCardLongPress(_ gesture: UILongPressGestureRecognizer) {
        guard gesture.state == .began else { return }
        let point = gesture.location(in: collectionView)
        guard let indexPath = collectionView.indexPathForItem(at: point),
              indexPath.item < visibleItems.count else { return }
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        showActions(for: visibleItems[indexPath.item])
    }

    private func showActions(for item: ClipItem) {
        hideActions()

        let panel = UIView()
        panel.translatesAutoresizingMaskIntoConstraints = false
        panel.backgroundColor = .systemBackground
        panel.layer.cornerRadius = 14
        panel.layer.shadowColor = UIColor.black.cgColor
        panel.layer.shadowOpacity = 0.25
        panel.layer.shadowRadius = 10
        panel.layer.shadowOffset = CGSize(width: 0, height: 3)

        let titleLabel = UILabel()
        titleLabel.text = item.text
        titleLabel.numberOfLines = 2
        titleLabel.lineBreakMode = .byTruncatingTail
        titleLabel.font = .systemFont(ofSize: 13)
        titleLabel.textColor = .secondaryLabel

        let pinButton = makeActionButton(title: item.pinned ? "📌 取消釘選" : "📌 釘選")
        pinButton.addAction(UIAction { [weak self] _ in
            self?.togglePin(item)
            self?.hideActions()
        }, for: .touchUpInside)

        let removeButton = makeActionButton(title: "🗑 刪除")
        removeButton.setTitleColor(.systemRed, for: .normal)
        removeButton.addAction(UIAction { [weak self] _ in
            self?.deleteItem(item)
            self?.hideActions()
        }, for: .touchUpInside)

        let cancelButton = makeActionButton(title: "取消")
        cancelButton.addAction(UIAction { [weak self] _ in
            self?.hideActions()
        }, for: .touchUpInside)

        let buttons = UIStackView(arrangedSubviews: [pinButton, removeButton, cancelButton])
        buttons.axis = .horizontal
        buttons.spacing = 8
        buttons.distribution = .fillEqually

        let content = UIStackView(arrangedSubviews: [titleLabel, buttons])
        content.translatesAutoresizingMaskIntoConstraints = false
        content.axis = .vertical
        content.spacing = 10

        panel.addSubview(content)
        view.addSubview(panel)

        NSLayoutConstraint.activate([
            content.topAnchor.constraint(equalTo: panel.topAnchor, constant: 12),
            content.bottomAnchor.constraint(equalTo: panel.bottomAnchor, constant: -12),
            content.leadingAnchor.constraint(equalTo: panel.leadingAnchor, constant: 12),
            content.trailingAnchor.constraint(equalTo: panel.trailingAnchor, constant: -12),
            buttons.heightAnchor.constraint(equalToConstant: 40),

            panel.centerYAnchor.constraint(equalTo: collectionView.centerYAnchor),
            panel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            panel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24)
        ])
        actionPanel = panel
    }

    private func hideActions() {
        actionPanel?.removeFromSuperview()
        actionPanel = nil
    }

    private func makeActionButton(title: String) -> UIButton {
        let button = UIButton(type: .system)
        button.setTitle(title, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 15, weight: .semibold)
        button.tintColor = .label
        button.backgroundColor = .systemGray5
        button.layer.cornerRadius = 10
        return button
    }

    /// 釘選／取消釘選：鍵盤自己記錄的那份直接改；App 那份送指令（App 在背景執行時會很快處理）
    private func togglePin(_ item: ClipItem) {
        let newPinned = !item.pinned

        var own = loadOwn()
        var ownChanged = false
        for index in own.indices where own[index].text == item.text {
            own[index].pinned = newPinned
            ownChanged = true
        }
        if ownChanged {
            saveOwn(own)
        }

        ClipShare.send(ClipCommand(action: newPinned ? "pin" : "unpin", id: item.id))

        if let index = allItems.firstIndex(where: { $0.id == item.id }) {
            allItems[index].pinned = newPinned
        }
        allItems = sortItems(allItems)
        rebuildChips()
        applyFilter()
    }

    /// 刪除：同樣內容在鍵盤自己記錄的那份也一併刪掉，避免又冒出來
    private func deleteItem(_ item: ClipItem) {
        var own = loadOwn()
        own.removeAll { $0.text == item.text }
        saveOwn(own)

        ClipShare.send(ClipCommand(action: "delete", id: item.id))

        allItems.removeAll { $0.id == item.id }
        rebuildChips()
        applyFilter()
    }

    @objc private func tapCursorLeft() {
        textDocumentProxy.adjustTextPosition(byCharacterOffset: -1)
    }

    @objc private func tapCursorRight() {
        textDocumentProxy.adjustTextPosition(byCharacterOffset: 1)
    }

    @objc private func holdDelete(_ gesture: UILongPressGestureRecognizer) {
        switch gesture.state {
        case .began:
            textDocumentProxy.deleteBackward()
            deleteTimer?.invalidate()
            deleteTimer = Timer.scheduledTimer(withTimeInterval: 0.08, repeats: true) { [weak self] _ in
                self?.textDocumentProxy.deleteBackward()
            }
        case .ended, .cancelled, .failed:
            deleteTimer?.invalidate()
            deleteTimer = nil
        default:
            break
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        deleteTimer?.invalidate()
        deleteTimer = nil
        hideActions()
    }

    @objc private func tapSpace() {
        textDocumentProxy.insertText(" ")
    }

    @objc private func tapDelete() {
        textDocumentProxy.deleteBackward()
    }

    @objc private func tapReturn() {
        textDocumentProxy.insertText("\n")
    }
}

// MARK: - 格狀清單

extension KeyboardViewController: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        visibleItems.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ClipCell.reuseID, for: indexPath) as? ClipCell else {
            return UICollectionViewCell()
        }
        cell.configure(with: visibleItems[indexPath.item])
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        textDocumentProxy.insertText(ClipTemplate.expand(visibleItems[indexPath.item].text))
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let cols = CGFloat(columns)
        let rowCount = CGFloat(rows)
        let width = floor((collectionView.bounds.width - spacing * (cols - 1)) / cols)
        let height = floor((collectionView.bounds.height - spacing * (rowCount - 1)) / rowCount)
        return CGSize(width: max(width, 30), height: max(height, 30))
    }
}
